export type AgeGroup = 'preschool' | 'early' | 'tween';

export interface ChildProfile {
  id: string;
  name: string;
  avatar: string;
  ageGroup: AgeGroup;
  xp: number;
  level: number;
  stars: number;
  streakDays: number;
  lastReadDate: string | null;
  streakShields: number;
  unlockedBadgeIds: string[];
  completedQuizCount: number;
  memorizedVerseIds: string[];
  totalQuestionsAnswered: number;
  correctAnswersCount: number;
}

export interface ScriptureQuest {
  id: string;
  dayNumber: number;
  theme: string;
  themeColor: string;
  reference: string;
  verseText: string;
  simplifiedForKids: string;
  kidTakeaway: string;
  actionChallenge: string;
  funFact: string;
  audioDurationSeconds: number;
  xpReward: number;
  starsReward: number;
  tags: string[];
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswerIndex: number;
  scriptureReference: string;
  explanation: string;
  funFact?: string;
  category: 'heroes' | 'jesus' | 'animals' | 'fruit' | 'miracles' | 'general';
  difficulty: 'easy' | 'medium' | 'hard';
}

export interface MemoryVersePuzzle {
  id: string;
  reference: string;
  theme: string;
  fullVerse: string;
  words: string[];
  translation: string;
  hint: string;
  category: string;
}

export interface BibleStory {
  id: string;
  title: string;
  subtitle: string;
  category: string;
  scripture: string;
  readTime: string;
  coverEmoji: string;
  bgGradient: string;
  summary: string;
  paragraphs: string[];
  moralLesson: string;
  memoryVerse: string;
  reflectionQuestion: string;
}

export interface Badge {
  id: string;
  title: string;
  description: string;
  icon: string;
  category: 'streak' | 'quiz' | 'memory' | 'stories' | 'explorer';
  requirement: string;
  xpBonus: number;
}

export interface WebIntegrationIdea {
  id: string;
  title: string;
  summary: string;
  howItEngagesKids: string;
  bibleKidsRoomFit: string;
  sampleEmbedCode?: string;
  category: 'Gamification' | 'Daily Habit' | 'Interactive Media' | 'Sunday School / Family';
}
