import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { DailyQuestHero } from './components/DailyQuestHero';
import { QuizArena } from './components/QuizArena';
import { VerseScrambleGame } from './components/VerseScrambleGame';
import { StoryTheater } from './components/StoryTheater';
import { BibleBuddyChat } from './components/BibleBuddyChat';
import { RewardsHall } from './components/RewardsHall';
import { WebsiteGuideTab } from './components/WebsiteGuideTab';
import { ParentDashboardModal } from './components/ParentDashboardModal';

import { ChildProfile, ScriptureQuest } from './types';
import {
  INITIAL_SCRIPTURE_QUESTS,
  INITIAL_QUIZ_BANK,
  INITIAL_MEMORY_VERSES,
  INITIAL_STORIES,
  INITIAL_BADGES
} from './data/initialData';
import { playSoundEffect } from './utils/audio';

const STORAGE_KEY_PROFILES = 'bkr_child_profiles_v1';
const STORAGE_KEY_ACTIVE_ID = 'bkr_active_profile_id_v1';

const DEFAULT_PROFILES: ChildProfile[] = [
  {
    id: 'profile-liam',
    name: 'Liam',
    avatar: '🦁',
    ageGroup: 'early',
    xp: 320,
    level: 3,
    stars: 28,
    streakDays: 4,
    lastReadDate: new Date().toISOString().split('T')[0],
    streakShields: 2,
    unlockedBadgeIds: ['badge-1', 'badge-2', 'badge-6'],
    completedQuizCount: 4,
    memorizedVerseIds: ['mem-1', 'mem-3'],
    totalQuestionsAnswered: 20,
    correctAnswersCount: 18
  },
  {
    id: 'profile-emma',
    name: 'Emma',
    avatar: '🕊️',
    ageGroup: 'tween',
    xp: 490,
    level: 4,
    stars: 45,
    streakDays: 7,
    lastReadDate: new Date().toISOString().split('T')[0],
    streakShields: 3,
    unlockedBadgeIds: ['badge-1', 'badge-2', 'badge-3', 'badge-4', 'badge-5'],
    completedQuizCount: 8,
    memorizedVerseIds: ['mem-1', 'mem-2', 'mem-3', 'mem-4'],
    totalQuestionsAnswered: 35,
    correctAnswersCount: 33
  }
];

export default function App() {
  // Profiles state with localStorage
  const [profiles, setProfiles] = useState<ChildProfile[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_PROFILES);
      if (saved) return JSON.parse(saved);
    } catch {}
    return DEFAULT_PROFILES;
  });

  const [activeProfileId, setActiveProfileId] = useState<string>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_ACTIVE_ID);
      if (saved && profiles.some(p => p.id === saved)) return saved;
    } catch {}
    return profiles[0]?.id || 'profile-liam';
  });

  const [currentTab, setCurrentTab] = useState<'quest' | 'quiz' | 'scramble' | 'stories' | 'buddy' | 'rewards' | 'suggestions'>('quest');
  const [currentQuestIndex, setCurrentQuestIndex] = useState<number>(0);
  const [scrambleTargetReference, setScrambleTargetReference] = useState<string | undefined>(undefined);
  const [parentModalOpen, setParentModalOpen] = useState<boolean>(false);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_PROFILES, JSON.stringify(profiles));
      localStorage.setItem(STORAGE_KEY_ACTIVE_ID, activeProfileId);
    } catch {}
  }, [profiles, activeProfileId]);

  const activeProfile = profiles.find(p => p.id === activeProfileId) || profiles[0];

  // Helper to update active profile stats
  const updateActiveProfile = (updater: (prev: ChildProfile) => ChildProfile) => {
    setProfiles(prevProfiles =>
      prevProfiles.map(p => {
        if (p.id === activeProfileId) {
          const updated = updater(p);
          // Check level upgrades (every 150 XP increases level)
          const newLevel = Math.max(1, Math.floor(updated.xp / 150) + 1);
          if (newLevel > updated.level) {
            updated.level = newLevel;
            if (soundEnabled) playSoundEffect('levelup');
          }
          return updated;
        }
        return p;
      })
    );
  };

  // Complete Daily Scripture Quest
  const handleCompleteQuest = (quest: ScriptureQuest) => {
    const todayStr = new Date().toISOString().split('T')[0];
    updateActiveProfile(prev => {
      const alreadyCompletedToday = prev.lastReadDate === todayStr;
      const newStreak = alreadyCompletedToday ? prev.streakDays : prev.streakDays + 1;
      
      const newBadges = [...prev.unlockedBadgeIds];
      if (!newBadges.includes('badge-1')) newBadges.push('badge-1');
      if (newStreak >= 3 && !newBadges.includes('badge-2')) newBadges.push('badge-2');
      if (newStreak >= 7 && !newBadges.includes('badge-3')) newBadges.push('badge-3');

      return {
        ...prev,
        streakDays: newStreak,
        lastReadDate: todayStr,
        xp: prev.xp + quest.xpReward,
        stars: prev.stars + quest.starsReward,
        unlockedBadgeIds: newBadges
      };
    });
  };

  // Quiz completion handler
  const handleQuizComplete = (score: number, total: number, xpEarned: number, starsEarned: number) => {
    updateActiveProfile(prev => {
      const newBadges = [...prev.unlockedBadgeIds];
      if (score === total && !newBadges.includes('badge-4')) {
        newBadges.push('badge-4');
      }

      return {
        ...prev,
        xp: prev.xp + xpEarned,
        stars: prev.stars + starsEarned,
        completedQuizCount: prev.completedQuizCount + 1,
        totalQuestionsAnswered: prev.totalQuestionsAnswered + total,
        correctAnswersCount: prev.correctAnswersCount + score,
        unlockedBadgeIds: newBadges
      };
    });
  };

  // Verse Memory Scramble master handler
  const handleMasterVerse = (verseId: string, xpEarned: number, starsEarned: number) => {
    updateActiveProfile(prev => {
      const newMemorized = prev.memorizedVerseIds.includes(verseId)
        ? prev.memorizedVerseIds
        : [...prev.memorizedVerseIds, verseId];

      const newBadges = [...prev.unlockedBadgeIds];
      if (newMemorized.length >= 3 && !newBadges.includes('badge-5')) {
        newBadges.push('badge-5');
      }

      return {
        ...prev,
        xp: prev.xp + xpEarned,
        stars: prev.stars + starsEarned,
        memorizedVerseIds: newMemorized,
        unlockedBadgeIds: newBadges
      };
    });
  };

  // Story read handler
  const handleReadStory = (storyId: string, xpEarned: number) => {
    updateActiveProfile(prev => {
      const newBadges = [...prev.unlockedBadgeIds];
      if (storyId.includes('noah') && !newBadges.includes('badge-6')) newBadges.push('badge-6');
      if (storyId.includes('david') && !newBadges.includes('badge-7')) newBadges.push('badge-7');

      return {
        ...prev,
        xp: prev.xp + xpEarned,
        unlockedBadgeIds: newBadges
      };
    });
  };

  // Streak shield usage
  const handleUseStreakShield = () => {
    updateActiveProfile(prev => ({
      ...prev,
      streakShields: Math.max(0, prev.streakShields - 1),
      unlockedBadgeIds: prev.unlockedBadgeIds.includes('badge-8') ? prev.unlockedBadgeIds : [...prev.unlockedBadgeIds, 'badge-8']
    }));
  };

  // Profile management from Parent dashboard
  const handleAddProfile = (name: string, avatar: string, ageGroup: 'preschool' | 'early' | 'tween') => {
    const newId = `profile-${Date.now()}`;
    const newProf: ChildProfile = {
      id: newId,
      name,
      avatar,
      ageGroup,
      xp: 0,
      level: 1,
      stars: 5,
      streakDays: 1,
      lastReadDate: new Date().toISOString().split('T')[0],
      streakShields: 2,
      unlockedBadgeIds: ['badge-1'],
      completedQuizCount: 0,
      memorizedVerseIds: [],
      totalQuestionsAnswered: 0,
      correctAnswersCount: 0
    };
    setProfiles(prev => [...prev, newProf]);
    setActiveProfileId(newId);
  };

  const handleUpdateStreak = (profileId: string, streak: number) => {
    setProfiles(prev =>
      prev.map(p => (p.id === profileId ? { ...p, streakDays: streak } : p))
    );
  };

  const handleJumpToScramble = (verseText: string, reference: string) => {
    setScrambleTargetReference(reference);
    setCurrentTab('scramble');
  };

  return (
    <div className="min-h-screen bg-[#faf8f5] text-slate-800 flex flex-col font-sans selection:bg-amber-200">
      
      {/* Navigation Header */}
      <Navbar
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        profile={activeProfile}
        profiles={profiles}
        onSelectProfile={setActiveProfileId}
        onOpenParentModal={() => setParentModalOpen(true)}
        soundEnabled={soundEnabled}
        onToggleSound={() => setSoundEnabled(!soundEnabled)}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {currentTab === 'quest' && (
          <DailyQuestHero
            quests={INITIAL_SCRIPTURE_QUESTS}
            currentQuestIndex={currentQuestIndex}
            onSelectQuestIndex={setCurrentQuestIndex}
            profile={activeProfile}
            onCompleteQuest={handleCompleteQuest}
            onJumpToScramble={handleJumpToScramble}
            soundEnabled={soundEnabled}
          />
        )}

        {currentTab === 'quiz' && (
          <QuizArena
            quizBank={INITIAL_QUIZ_BANK}
            profile={activeProfile}
            onQuizComplete={handleQuizComplete}
            soundEnabled={soundEnabled}
          />
        )}

        {currentTab === 'scramble' && (
          <VerseScrambleGame
            verses={INITIAL_MEMORY_VERSES}
            profile={activeProfile}
            onMasterVerse={handleMasterVerse}
            soundEnabled={soundEnabled}
            initialVerseReference={scrambleTargetReference}
          />
        )}

        {currentTab === 'stories' && (
          <StoryTheater
            stories={INITIAL_STORIES}
            profile={activeProfile}
            onReadStory={handleReadStory}
            soundEnabled={soundEnabled}
          />
        )}

        {currentTab === 'buddy' && (
          <BibleBuddyChat
            profile={activeProfile}
            soundEnabled={soundEnabled}
          />
        )}

        {currentTab === 'rewards' && (
          <RewardsHall
            badges={INITIAL_BADGES}
            profile={activeProfile}
            onUseStreakShield={handleUseStreakShield}
            soundEnabled={soundEnabled}
          />
        )}

        {currentTab === 'suggestions' && (
          <WebsiteGuideTab />
        )}
      </main>

      {/* Parent & Sunday School Leader Dashboard Modal */}
      <ParentDashboardModal
        isOpen={parentModalOpen}
        onClose={() => setParentModalOpen(false)}
        profiles={profiles}
        activeProfileId={activeProfileId}
        onSelectProfile={setActiveProfileId}
        onAddProfile={handleAddProfile}
        onUpdateStreak={handleUpdateStreak}
      />

      {/* Footer */}
      <footer className="border-t border-amber-100 bg-white py-6 mt-12 text-center text-xs text-slate-500 space-y-2">
        <div className="flex items-center justify-center gap-4 flex-wrap font-semibold text-slate-600">
          <button onClick={() => setCurrentTab('quest')} className="hover:text-amber-600">Daily Quest</button>
          <span>•</span>
          <button onClick={() => setCurrentTab('quiz')} className="hover:text-amber-600">Quiz Arena</button>
          <span>•</span>
          <button onClick={() => setCurrentTab('scramble')} className="hover:text-amber-600">Memory Scramble</button>
          <span>•</span>
          <button onClick={() => setCurrentTab('stories')} className="hover:text-amber-600">Story Theater</button>
          <span>•</span>
          <button onClick={() => setCurrentTab('buddy')} className="hover:text-amber-600">Bible Buddy AI</button>
          <span>•</span>
          <button onClick={() => setCurrentTab('suggestions')} className="text-indigo-600 hover:text-indigo-800">
            biblekidsroom.com Integration Suite
          </button>
        </div>
        <p className="font-medium text-slate-400">
          Designed with ❤️ for <a href="https://biblekidsroom.com" target="_blank" rel="noopener noreferrer" className="font-bold text-amber-700 hover:underline">BibleKidsRoom.com</a> — Engaging children with God's Word through fun, gamification, and daily scripture habits.
        </p>
      </footer>

    </div>
  );
}
