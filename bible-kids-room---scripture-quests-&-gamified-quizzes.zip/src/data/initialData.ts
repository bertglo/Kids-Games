import { ScriptureQuest, QuizQuestion, MemoryVersePuzzle, BibleStory, Badge, WebIntegrationIdea } from '../types';

export const INITIAL_SCRIPTURE_QUESTS: ScriptureQuest[] = [
  {
    id: 'quest-1',
    dayNumber: 1,
    theme: 'Courage & Trust',
    themeColor: 'from-amber-500 to-orange-500',
    reference: 'Joshua 1:9',
    verseText: 'Be strong and courageous. Do not be afraid; do not be discouraged, for the Lord your God will be with you wherever you go.',
    simplifiedForKids: 'Be brave and full of courage! You never have to be scared because God is right with you everywhere you go!',
    kidTakeaway: 'When you face something new or hard—like a big test, a new school day, or the dark—remember God holds your hand!',
    actionChallenge: 'Give someone a high-five today and say: "God is with you!"',
    funFact: 'Joshua was chosen by God to lead millions of people across the Jordan River into the Promised Land!',
    audioDurationSeconds: 15,
    xpReward: 50,
    starsReward: 5,
    tags: ['Courage', 'Hero', 'Old Testament']
  },
  {
    id: 'quest-2',
    dayNumber: 2,
    theme: 'Love & Kindness',
    themeColor: 'from-rose-500 to-pink-500',
    reference: '1 John 4:19',
    verseText: 'We love because He first loved us.',
    simplifiedForKids: 'We can share big, joyful love with everyone because God loved us first!',
    kidTakeaway: 'Love is like a superpower. When you share a toy or say a kind word, you shine God\'s warm love like a flashlight.',
    actionChallenge: 'Draw a cheerful picture or write a sweet note for your mom, dad, or teacher.',
    funFact: 'The word "love" appears over 500 times in the Bible!',
    audioDurationSeconds: 10,
    xpReward: 50,
    starsReward: 5,
    tags: ['Love', 'Kindness', 'Heart']
  },
  {
    id: 'quest-3',
    dayNumber: 3,
    theme: 'Joy & Light',
    themeColor: 'from-yellow-400 to-amber-500',
    reference: 'Matthew 5:16',
    verseText: 'Let your light shine before others, that they may see your good deeds and glorify your Father in heaven.',
    simplifiedForKids: 'Shine your bright light so people see your good actions and thank God!',
    kidTakeaway: 'You don\'t need to be a grown-up to make a difference. Even a small smile lights up a whole room.',
    actionChallenge: 'Help clean up without being asked first!',
    funFact: 'Jesus compared believers to a city set on top of a hill that cannot be hidden at night.',
    audioDurationSeconds: 12,
    xpReward: 50,
    starsReward: 5,
    tags: ['Light', 'Jesus', 'Gospel']
  },
  {
    id: 'quest-4',
    dayNumber: 4,
    theme: 'Strength & Peace',
    themeColor: 'from-emerald-500 to-teal-500',
    reference: 'Philippians 4:13',
    verseText: 'I can do all this through Him who gives me strength.',
    simplifiedForKids: 'With Jesus giving me strength inside, I can accomplish anything He calls me to do!',
    kidTakeaway: 'When things feel tough or you want to give up, pause and pray: "Jesus, give me Your strength!"',
    actionChallenge: 'Practice something tricky you are learning (like tying shoes or math) and thank God for your brain!',
    funFact: 'Paul wrote these inspiring words while in prison, showing that joy comes from God, not circumstances!',
    audioDurationSeconds: 10,
    xpReward: 50,
    starsReward: 5,
    tags: ['Strength', 'Faith', 'New Testament']
  },
  {
    id: 'quest-5',
    dayNumber: 5,
    theme: 'The Armor of God',
    themeColor: 'from-blue-500 to-indigo-600',
    reference: 'Ephesians 6:11',
    verseText: 'Put on the full armor of God, so that you can take your stand against the devil’s schemes.',
    simplifiedForKids: 'Put on God’s special spiritual armor—truth, faith, peace, and salvation—every morning!',
    kidTakeaway: 'Imagine buckling on the belt of truth and holding the shiny shield of faith before you leave bed!',
    actionChallenge: 'Act out putting on each piece of God\'s armor with fun superhero poses!',
    funFact: 'Roman soldiers had armor that weighed up to 60 pounds, but God\'s armor is lightweight and made of truth & love!',
    audioDurationSeconds: 14,
    xpReward: 50,
    starsReward: 5,
    tags: ['Armor', 'Superhero', 'Protection']
  }
];

export const INITIAL_QUIZ_BANK: QuizQuestion[] = [
  // Heroes
  {
    id: 'q-hero-1',
    question: 'Who defeated the giant warrior Goliath with just a sling and 5 smooth stones?',
    options: ['Samson', 'David', 'Gideon', 'Solomon'],
    correctAnswerIndex: 1,
    scriptureReference: '1 Samuel 17:49-50',
    explanation: 'David was a young shepherd boy who trusted God completely to defeat the giant Goliath.',
    funFact: 'David later became the greatest king of Israel and wrote many beautiful Psalms!',
    category: 'heroes',
    difficulty: 'easy'
  },
  {
    id: 'q-hero-2',
    question: 'Who survived inside a den of hungry lions because God sent an angel to shut their mouths?',
    options: ['Daniel', 'Joseph', 'Elijah', 'Jonah'],
    correctAnswerIndex: 0,
    scriptureReference: 'Daniel 6:22',
    explanation: 'Daniel prayed faithfully three times a day, and God protected him completely from the lions.',
    funFact: 'King Darius was so happy Daniel survived that he told everyone to worship Daniel\'s God!',
    category: 'heroes',
    difficulty: 'easy'
  },
  {
    id: 'q-hero-3',
    question: 'Which brave queen risked her life to save her Jewish people by speaking to the King?',
    options: ['Ruth', 'Esther', 'Sarah', 'Deborah'],
    correctAnswerIndex: 1,
    scriptureReference: 'Esther 4:14-16',
    explanation: 'Queen Esther bravely said, "For such a time as this," and God used her courage to save her people.',
    funFact: 'The Jewish holiday of Purim celebrates Esther\'s courage with treats and celebration!',
    category: 'heroes',
    difficulty: 'medium'
  },
  // Jesus & Gospels
  {
    id: 'q-jesus-1',
    question: 'Where was baby Jesus born?',
    options: ['In a palace in Rome', 'In a stable in Bethlehem', 'On a boat on the Sea of Galilee', 'In Jerusalem temple'],
    correctAnswerIndex: 1,
    scriptureReference: 'Luke 2:7',
    explanation: 'Mary wrapped baby Jesus in cloths and placed Him in a manger because there was no room in the inn.',
    funFact: 'Shepherds were the first visitors invited by angels to see baby Jesus!',
    category: 'jesus',
    difficulty: 'easy'
  },
  {
    id: 'q-jesus-2',
    question: 'What did Jesus do during a fierce storm while His disciples were terrified in their boat?',
    options: ['He commanded the wind and waves to be still', 'He swam to shore', 'He told them to row harder', 'He made it rain fish'],
    correctAnswerIndex: 0,
    scriptureReference: 'Mark 4:39',
    explanation: 'Jesus said, "Peace! Be still!" and the wind died down and the water became completely calm.',
    funFact: 'The disciples were amazed and asked, "Who is this? Even the wind and the waves obey Him!"',
    category: 'jesus',
    difficulty: 'easy'
  },
  {
    id: 'q-jesus-3',
    question: 'How many loaves of bread and small fish did Jesus multiply to feed over 5,000 people?',
    options: ['10 loaves and 5 fish', '5 loaves and 2 fish', '1 loaf and 1 fish', '7 loaves and 7 fish'],
    correctAnswerIndex: 1,
    scriptureReference: 'John 6:9-13',
    explanation: 'A young boy shared his lunch of 5 barley loaves and 2 small fish, and Jesus fed thousands with 12 baskets left over!',
    funFact: 'This shows God can take small gifts from kids and do gigantic miracles!',
    category: 'jesus',
    difficulty: 'medium'
  },
  // Animals & Nature
  {
    id: 'q-anim-1',
    question: 'Which bird did Noah first send out of the ark to see if the floodwaters had dried up?',
    options: ['A dove', 'A raven', 'An eagle', 'A sparrow'],
    correctAnswerIndex: 1,
    scriptureReference: 'Genesis 8:7',
    explanation: 'Noah first sent out a raven, and later sent out a dove which returned with a fresh olive leaf in its beak.',
    funFact: 'Ravens are super smart birds that can fly great distances without resting!',
    category: 'animals',
    difficulty: 'medium'
  },
  {
    id: 'q-anim-2',
    question: 'What great sea creature swallowed Jonah when he tried to run away from God\'s call to Nineveh?',
    options: ['A giant sea turtle', 'A great fish / whale', 'A giant octopus', 'A shark'],
    correctAnswerIndex: 1,
    scriptureReference: 'Jonah 1:17',
    explanation: 'God provided a huge fish to swallow Jonah, where he prayed for 3 days and nights before being safely spat onto land.',
    funFact: 'Blue whales have hearts the size of a small car!',
    category: 'animals',
    difficulty: 'easy'
  },
  // Fruit of the Spirit
  {
    id: 'q-fruit-1',
    question: 'Which of the following is NOT one of the 9 Fruits of the Spirit listed in Galatians 5?',
    options: ['Joy', 'Patience', 'Jealousy', 'Gentleness'],
    correctAnswerIndex: 2,
    scriptureReference: 'Galatians 5:22-23',
    explanation: 'The fruit of the Spirit is love, joy, peace, patience, kindness, goodness, faithfulness, gentleness, and self-control.',
    funFact: 'Just like good fruit grows on healthy apple trees, the Holy Spirit grows these virtues in our hearts!',
    category: 'fruit',
    difficulty: 'easy'
  },
  {
    id: 'q-fruit-2',
    question: 'How many fruits of the Holy Spirit are described in Galatians 5?',
    options: ['3', '7', '9', '12'],
    correctAnswerIndex: 2,
    scriptureReference: 'Galatians 5:22-23',
    explanation: 'There are 9 beautiful fruits of the Spirit that show up in how we treat others.',
    funFact: 'Self-control is the ninth fruit—it helps us make good choices even when it is hard!',
    category: 'fruit',
    difficulty: 'medium'
  }
];

export const INITIAL_MEMORY_VERSES: MemoryVersePuzzle[] = [
  {
    id: 'mem-1',
    reference: 'Psalm 119:105',
    theme: 'Guidance & Light',
    fullVerse: 'Your word is a lamp for my feet, a light on my path.',
    words: ['Your', 'word', 'is', 'a', 'lamp', 'for', 'my', 'feet,', 'a', 'light', 'on', 'my', 'path.'],
    translation: 'NIV',
    hint: 'God\'s word guides us in the dark like a bright lantern!',
    category: 'Wisdom'
  },
  {
    id: 'mem-2',
    reference: 'Proverbs 3:5',
    theme: 'Trust in God',
    fullVerse: 'Trust in the Lord with all your heart and lean not on your own understanding.',
    words: ['Trust', 'in', 'the', 'Lord', 'with', 'all', 'your', 'heart', 'and', 'lean', 'not', 'on', 'your', 'own', 'understanding.'],
    translation: 'NIV',
    hint: 'Rely on God\'s wisdom rather than trying to figure everything out alone.',
    category: 'Trust'
  },
  {
    id: 'mem-3',
    reference: 'Philippians 4:13',
    theme: 'Strength',
    fullVerse: 'I can do all things through Christ who gives me strength.',
    words: ['I', 'can', 'do', 'all', 'things', 'through', 'Christ', 'who', 'gives', 'me', 'strength.'],
    translation: 'NKJV',
    hint: 'Jesus is our source of supernatural courage and power!',
    category: 'Courage'
  },
  {
    id: 'mem-4',
    reference: 'John 3:16',
    theme: 'God\'s Love',
    fullVerse: 'For God so loved the world that He gave His one and only Son.',
    words: ['For', 'God', 'so', 'loved', 'the', 'world', 'that', 'He', 'gave', 'His', 'one', 'and', 'only', 'Son.'],
    translation: 'NIV',
    hint: 'The most famous verse in the whole Bible about God\'s eternal love.',
    category: 'Love'
  }
];

export const INITIAL_STORIES: BibleStory[] = [
  {
    id: 'story-creation',
    title: 'The Great Masterpiece: Creation',
    subtitle: 'How God made the universe with His joyful word',
    category: 'Beginnings',
    scripture: 'Genesis 1-2',
    readTime: '3 min',
    coverEmoji: '🌍',
    bgGradient: 'from-blue-600 via-indigo-600 to-purple-700',
    summary: 'From darkness and silence, God spoke and created shimmering stars, splashy oceans, playful animals, and people in His image!',
    paragraphs: [
      'In the very beginning, before there were playgrounds, puppies, or ice cream cones, there was only God. The world was completely dark and quiet.',
      'Then God spoke into the darkness: "Let there be light!" And instant brightness danced across the skies! God made the blue heavens, the roaring oceans, and lush green forests filled with apple and mango trees.',
      'Next, God filled the sky with birds of every color and the seas with leaping dolphins and gigantic whales. On the land, He made lions, puppies, and kangaroos.',
      'Finally, God did His most special creation of all: He made people! God looked at everything He had made and smiled with great joy—it was very good.'
    ],
    moralLesson: 'You are God\'s special, wonderful creation. He made you on purpose and loves you immensely!',
    memoryVerse: 'In the beginning God created the heavens and the earth. — Genesis 1:1',
    reflectionQuestion: 'What is your favorite animal or part of nature that God created?'
  },
  {
    id: 'story-noah',
    title: 'Noah and the Big Rainbow Promise',
    subtitle: 'Faith, floating animals, and God\'s colorful promise',
    category: 'Old Testament',
    scripture: 'Genesis 6-9',
    readTime: '4 min',
    coverEmoji: '🚢',
    bgGradient: 'from-teal-500 via-cyan-600 to-blue-700',
    summary: 'Noah obeyed God by building a giant wooden ark to keep his family and pairs of all animals safe during the big storm.',
    paragraphs: [
      'Noah was a good man who loved God with all his heart. One day, God told Noah to build an enormous wooden ship called an Ark, even though it was sunny and there was no ocean nearby!',
      'People laughed at Noah, but Noah kept hammering and sawing. Soon, animals of all shapes and sizes began marching into the ark two by two—tall giraffes, fluffy sheep, and tiny ladybugs.',
      'The rain fell for 40 days, but Noah\'s family and all the animals were safe and cozy inside. When the storm finally stopped, Noah sent out a white dove, and it returned with a green olive branch.',
      'God painted a glowing, vibrant rainbow across the sky as a promise: "Whenever you see my rainbow in the clouds, remember I will never flood the whole earth again."'
    ],
    moralLesson: 'Obeying God is always the best choice, even when others don\'t understand. God always keeps His promises!',
    memoryVerse: 'I have set my rainbow in the clouds, and it will be the sign of the covenant. — Genesis 9:13',
    reflectionQuestion: 'How do you feel when you see a rainbow in the sky after a rainy day?'
  },
  {
    id: 'story-david',
    title: 'David and the Giant with a Mighty Heart',
    subtitle: 'How a shepherd boy with faith stood up to Goliath',
    category: 'Old Testament',
    scripture: '1 Samuel 17',
    readTime: '3 min',
    coverEmoji: '🛡️',
    bgGradient: 'from-amber-600 via-orange-600 to-red-600',
    summary: 'While everyone was terrified of the 9-foot giant Goliath, young David knew God was bigger than any giant.',
    paragraphs: [
      'A huge army was shaking with fear. A giant named Goliath, standing over 9 feet tall with heavy bronze armor, came out every morning booming insults and daring anyone to fight him.',
      'A young shepherd boy named David came to the camp to bring bread and cheese to his older brothers. When David heard Goliath mocking God, David said, "Who is this giant? God is much bigger!"',
      'King Saul tried to put heavy armor on David, but it was too big. Instead, David took his shepherd staff, five smooth stones from the babbling brook, and his sling.',
      'David ran toward the giant shouting, "You come against me with sword and spear, but I come against you in the name of the Lord!" David swung his sling—ZING! The stone struck the giant, and God gave His people a mighty victory.'
    ],
    moralLesson: 'No matter how big your problems or fears seem, God is infinitely bigger and fights for you!',
    memoryVerse: 'The battle is the Lord\'s! — 1 Samuel 17:47',
    reflectionQuestion: 'What is one fear you can give to God today?'
  },
  {
    id: 'story-good-samaritan',
    title: 'The Kind Neighbor: The Good Samaritan',
    subtitle: 'Jesus shows us how to love everyone with kindness',
    category: 'Parables of Jesus',
    scripture: 'Luke 10:25-37',
    readTime: '3 min',
    coverEmoji: '❤️',
    bgGradient: 'from-rose-500 via-pink-600 to-purple-600',
    summary: 'When a traveler was hurt on a bumpy road, an unlikely helper stopped to bandage his wounds and care for him.',
    paragraphs: [
      'Jesus told a story to teach what it means to be a true neighbor. A man was walking down a lonely rocky road from Jerusalem to Jericho when robbers attacked him and left him hurt beside the road.',
      'Two important travelers walked past him on the opposite side of the road and did not stop to help.',
      'Then a Samaritan traveler came along. People from Samaria were usually not friends with Jewish people, but when he saw the hurting man, his heart filled with deep compassion.',
      'He gently bandaged his wounds, placed him on his own donkey, took him to a comfortable inn, and paid all the bills so the man could heal. Jesus said, "Go and do likewise!"'
    ],
    moralLesson: 'Being a loving neighbor means showing kindness and help to anyone in need, no matter who they are.',
    memoryVerse: 'Love your neighbor as yourself. — Luke 10:27',
    reflectionQuestion: 'How can you be a kind helper to someone at school or in your neighborhood this week?'
  }
];

export const INITIAL_BADGES: Badge[] = [
  {
    id: 'badge-1',
    title: 'First Step Explorer',
    description: 'Completed your very first Daily Scripture Quest!',
    icon: '🌟',
    category: 'explorer',
    requirement: 'Complete 1 Quest',
    xpBonus: 50
  },
  {
    id: 'badge-2',
    title: '3-Day Fire Spark',
    description: 'Maintained a 3-Day Daily Bible Reading Streak!',
    icon: '🔥',
    category: 'streak',
    requirement: '3-Day Streak',
    xpBonus: 100
  },
  {
    id: 'badge-3',
    title: '7-Day Golden Flame',
    description: 'Read God\'s Word 7 days in a row without breaking!',
    icon: '🏆',
    category: 'streak',
    requirement: '7-Day Streak',
    xpBonus: 250
  },
  {
    id: 'badge-4',
    title: 'Bible Trivia Whiz',
    description: 'Scored 100% on any interactive Bible Quiz!',
    icon: '🧠',
    category: 'quiz',
    requirement: 'Perfect Quiz Score',
    xpBonus: 150
  },
  {
    id: 'badge-5',
    title: 'Memory Verse Champion',
    description: 'Solved and mastered 3 Scripture word scrambles!',
    icon: '🧩',
    category: 'memory',
    requirement: 'Master 3 Verses',
    xpBonus: 200
  },
  {
    id: 'badge-6',
    title: 'Ark Explorer',
    description: 'Listened to and completed the story of Noah\'s Ark!',
    icon: '🚢',
    category: 'stories',
    requirement: 'Complete Noah Story',
    xpBonus: 100
  },
  {
    id: 'badge-7',
    title: 'Giant Slayer Courage',
    description: 'Read the story of David & Goliath and reflected on courage!',
    icon: '🛡️',
    category: 'stories',
    requirement: 'Complete David Story',
    xpBonus: 100
  },
  {
    id: 'badge-8',
    title: 'Shield Defender',
    description: 'Protected your reading streak with a Streak Shield!',
    icon: '✨',
    category: 'streak',
    requirement: 'Use Streak Shield',
    xpBonus: 75
  }
];

// App Ideas & Strategic Roadmap for biblekidsroom.com website
export const BIBLE_KIDS_ROOM_APP_SUGGESTIONS: WebIntegrationIdea[] = [
  {
    id: 'idea-1',
    title: 'Daily Scripture Streak & Quest Widget',
    category: 'Daily Habit',
    summary: 'A lightweight, embeddable or standalone web module that serves a daily 60-second child-friendly verse with audio narration, interactive reflection prompt, and gamified streak flame.',
    howItEngagesKids: 'Children love seeing their streak flame grow day after day, earning XP, collecting stars, and unlocking level avatars from "Little Lamb" to "Faith Champion".',
    bibleKidsRoomFit: 'Can be placed right on the homepage hero or as a dedicated /quest page. Creates sticky daily return visits to biblekidsroom.com for morning devotions or bedtime routines.',
    sampleEmbedCode: '<iframe src="https://biblekidsroom.com/embed/daily-quest" width="100%" height="480" frameborder="0"></iframe>'
  },
  {
    id: 'idea-2',
    title: 'Interactive Bible Quiz Arena & Weekly Trivia League',
    category: 'Gamification',
    summary: 'Engaging multiple-choice and true/false trivia tournaments with categories (Bible Animals, Superheroes of Faith, Miracles of Jesus, Armor of God) with instant sound feedback and leaderboards.',
    howItEngagesKids: 'High-energy feedback, celebratory confetti, fun facts, and progressive difficulty keeps children excited about Bible trivia rather than seeing it as a test.',
    bibleKidsRoomFit: 'Host a "Sunday School Quiz of the Week" or "Family Friday Trivia" on biblekidsroom.com where kids and Sunday School classes compete for weekly badges.',
    sampleEmbedCode: '<div id="bkr-quiz-widget" data-theme="heroes" data-count="5"></div>'
  },
  {
    id: 'idea-3',
    title: 'Scripture Memory Verse Scramble & Jigsaw Game',
    category: 'Interactive Media',
    summary: 'A drag-and-drop or tap-to-order word puzzle that helps children memorize key Bible verses in a fun, kinetic way with audio pronunciation and hints.',
    howItEngagesKids: 'Turn rote memorization into a fun jigsaw puzzle with 3 stages: Full Verse with Guide -> Fill in the Blanks -> Blind Master Challenge.',
    bibleKidsRoomFit: 'Pairs directly with weekly Sunday School memory verses or monthly themes on biblekidsroom.com.',
    sampleEmbedCode: '<iframe src="https://biblekidsroom.com/embed/memory-puzzle?verse=joshua-1-9" width="100%" height="400"></iframe>'
  },
  {
    id: 'idea-4',
    title: 'Interactive Illustrated Audio Story Theater & AI Junior Explorer',
    category: 'Interactive Media',
    summary: 'Richly narrated Bible stories with child-safe AI Q&A ("Bible Buddy") where curious kids can ask questions like "Why did Noah need two animals?" or generate custom bedtime prayers.',
    howItEngagesKids: 'Combines soothing audio narration with interactive curiosity, giving children immediate encouraging scripture-backed answers to their questions.',
    bibleKidsRoomFit: 'Provides deep educational value that parents and teachers will bookmark and recommend to other families.',
    sampleEmbedCode: '<div id="bkr-story-theater" data-story="david-goliath"></div>'
  },
  {
    id: 'idea-5',
    title: 'Printable Scripture Champion Certificates & Parent Dashboard',
    category: 'Sunday School / Family',
    summary: 'A rewarding printable certificate maker that automatically creates customized PDF/printable awards with the child\'s name, streak milestones, and verses learned.',
    howItEngagesKids: 'Kids can proudly hang their physical certificate on the refrigerator or show it to their grandparents and church teachers.',
    bibleKidsRoomFit: 'High viral sharing potential when parents share photos of their kids with their certificates on social media, tagging biblekidsroom.com.',
    sampleEmbedCode: '<a href="https://biblekidsroom.com/certificate-generator" class="btn">Print Your Badge Certificate</a>'
  }
];
