import React, { useState } from 'react';
import { Flame, Star, Volume2, VolumeX, Sparkles, BookOpen, Brain, Trophy, Bot, Award, Users, Globe, ChevronDown, Check } from 'lucide-react';
import { ChildProfile } from '../types';

interface NavbarProps {
  currentTab: 'quest' | 'quiz' | 'scramble' | 'stories' | 'buddy' | 'rewards' | 'suggestions';
  onSelectTab: (tab: 'quest' | 'quiz' | 'scramble' | 'stories' | 'buddy' | 'rewards' | 'suggestions') => void;
  profile: ChildProfile;
  profiles: ChildProfile[];
  onSelectProfile: (id: string) => void;
  onOpenParentModal: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  onSelectTab,
  profile,
  profiles,
  onSelectProfile,
  onOpenParentModal,
  soundEnabled,
  onToggleSound
}) => {
  const [profileDropdownOpen, setProfileDropdownOpen] = useState(false);

  // Level calculations: Level 1 = 0-100 XP, Level 2 = 100-250, Level 3 = 250-500, etc.
  const nextLevelXp = profile.level * 150;
  const currentLevelBaseXp = (profile.level - 1) * 150;
  const xpInCurrentLevel = Math.max(0, profile.xp - currentLevelBaseXp);
  const xpNeeded = nextLevelXp - currentLevelBaseXp;
  const xpPercent = Math.min(100, Math.round((xpInCurrentLevel / xpNeeded) * 100));

  const getRankTitle = (lvl: number) => {
    if (lvl === 1) return 'Little Lamb 🐑';
    if (lvl === 2) return 'Brave Dove 🕊️';
    if (lvl === 3) return 'Mighty Lion 🦁';
    if (lvl === 4) return 'Armor Knight 🛡️';
    return 'Faith Champion 👑';
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-amber-100 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20 gap-2">
          
          {/* Logo & Website Title */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => onSelectTab('quest')}>
            <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-2xl bg-gradient-to-tr from-amber-400 via-orange-400 to-rose-400 flex items-center justify-center text-xl sm:text-2xl shadow-sm text-white border-2 border-white">
              📖
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-lg sm:text-xl tracking-tight text-slate-800">
                  Bible<span className="text-amber-500">Kids</span>Room
                </span>
                <span className="hidden sm:inline-block px-2 py-0.5 text-xs font-bold bg-amber-100 text-amber-800 rounded-full">
                  .com
                </span>
              </div>
              <p className="text-[11px] sm:text-xs font-medium text-slate-500 hidden sm:block">
                Scripture Quests, Streaks & Interactive Quizzes
              </p>
            </div>
          </div>

          {/* Gamified HUD: Streak, Stars, XP Progress, Sound Toggle */}
          <div className="flex items-center gap-2 sm:gap-4">
            
            {/* Streak Counter */}
            <div 
              id="streak-badge"
              onClick={() => onSelectTab('rewards')}
              className="flex items-center gap-1.5 bg-gradient-to-r from-orange-500/10 to-amber-500/10 border border-orange-200 text-orange-700 px-2.5 py-1.5 rounded-xl cursor-pointer hover:bg-orange-100/60 transition-all"
              title="Daily Bible Reading Streak! Read daily to keep your flame burning."
            >
              <Flame className="w-5 h-5 text-orange-500 animate-pulse fill-orange-500" />
              <div className="flex flex-col text-left">
                <span className="text-xs font-black leading-none">{profile.streakDays} Day{profile.streakDays === 1 ? '' : 's'}</span>
                <span className="text-[9px] font-semibold text-orange-600 uppercase tracking-wider hidden sm:inline">Streak</span>
              </div>
            </div>

            {/* Stars Counter */}
            <div 
              id="stars-badge"
              onClick={() => onSelectTab('rewards')}
              className="flex items-center gap-1.5 bg-amber-50 border border-amber-200 text-amber-800 px-2.5 py-1.5 rounded-xl cursor-pointer hover:bg-amber-100/60 transition-all"
              title="Stars earned from quizzes and scripture memory."
            >
              <Star className="w-4 h-4 text-amber-500 fill-amber-400" />
              <span className="text-xs sm:text-sm font-black">{profile.stars}</span>
            </div>

            {/* Level & XP Mini Bar */}
            <div 
              id="xp-level-bar"
              onClick={() => onSelectTab('rewards')}
              className="hidden md:flex items-center gap-2 bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-xl cursor-pointer hover:bg-slate-100 transition-all"
              title={`Level ${profile.level}: ${getRankTitle(profile.level)} (${profile.xp} XP total)`}
            >
              <div className="text-left">
                <div className="flex items-center justify-between text-[11px] font-bold text-slate-700 gap-2">
                  <span>Lvl {profile.level}</span>
                  <span className="text-[10px] text-slate-500 font-medium">{xpInCurrentLevel}/{xpNeeded} XP</span>
                </div>
                <div className="w-20 h-2 bg-slate-200 rounded-full overflow-hidden mt-0.5">
                  <div 
                    className="h-full bg-gradient-to-r from-amber-400 to-orange-500 rounded-full transition-all duration-500"
                    style={{ width: `${xpPercent}%` }}
                  />
                </div>
              </div>
            </div>

            {/* Profile Avatar Dropdown */}
            <div className="relative">
              <button
                id="profile-dropdown-btn"
                onClick={() => setProfileDropdownOpen(!profileDropdownOpen)}
                className="flex items-center gap-1.5 p-1 sm:px-2.5 sm:py-1 rounded-xl bg-amber-50/80 hover:bg-amber-100/80 border border-amber-200 transition-all text-left"
              >
                <span className="text-xl sm:text-2xl">{profile.avatar}</span>
                <div className="hidden sm:block">
                  <p className="text-xs font-bold text-slate-800 leading-tight">{profile.name}</p>
                  <p className="text-[10px] text-amber-700 font-medium">{getRankTitle(profile.level).split(' ')[0]}</p>
                </div>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              </button>

              {profileDropdownOpen && (
                <div className="absolute right-0 mt-2 w-56 bg-white rounded-2xl shadow-xl border border-slate-100 py-2 z-50 animate-in fade-in zoom-in-95 duration-100">
                  <div className="px-3 py-2 border-b border-slate-100">
                    <p className="text-xs font-bold text-slate-700">Switch Child Profile</p>
                    <p className="text-[10px] text-slate-400">Track individual reading streaks</p>
                  </div>
                  {profiles.map(p => (
                    <button
                      key={p.id}
                      onClick={() => {
                        onSelectProfile(p.id);
                        setProfileDropdownOpen(false);
                      }}
                      className="w-full flex items-center justify-between px-3 py-2 text-left hover:bg-amber-50/60 transition-colors"
                    >
                      <div className="flex items-center gap-2">
                        <span className="text-xl">{p.avatar}</span>
                        <div>
                          <p className="text-xs font-bold text-slate-800">{p.name}</p>
                          <p className="text-[10px] text-slate-500">Lvl {p.level} • {p.streakDays}d Streak 🔥</p>
                        </div>
                      </div>
                      {p.id === profile.id && <Check className="w-4 h-4 text-amber-600" />}
                    </button>
                  ))}
                  <div className="border-t border-slate-100 mt-1 pt-1 px-2">
                    <button
                      onClick={() => {
                        setProfileDropdownOpen(false);
                        onOpenParentModal();
                      }}
                      className="w-full text-center py-1.5 text-xs font-bold text-amber-700 hover:bg-amber-50 rounded-lg flex items-center justify-center gap-1.5"
                    >
                      <Users className="w-3.5 h-3.5" />
                      Parent / Teacher Room
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Sound Toggle */}
            <button
              id="sound-toggle-btn"
              onClick={onToggleSound}
              className="p-2 rounded-xl text-slate-500 hover:text-slate-800 hover:bg-slate-100 transition-colors"
              title={soundEnabled ? 'Mute Sound Effects' : 'Unmute Sound Effects'}
            >
              {soundEnabled ? <Volume2 className="w-5 h-5 text-amber-600" /> : <VolumeX className="w-5 h-5 text-slate-400" />}
            </button>
          </div>
        </div>

        {/* Navigation Tabs Bar */}
        <nav className="flex items-center gap-1 sm:gap-2 overflow-x-auto no-scrollbar py-2 border-t border-slate-100 text-xs sm:text-sm font-bold">
          <button
            id="nav-tab-quest"
            onClick={() => onSelectTab('quest')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl whitespace-nowrap transition-all ${
              currentTab === 'quest'
                ? 'bg-amber-500 text-white shadow-xs'
                : 'text-slate-600 hover:bg-amber-50 hover:text-amber-900'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>Daily Quest & Streak</span>
          </button>

          <button
            id="nav-tab-quiz"
            onClick={() => onSelectTab('quiz')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl whitespace-nowrap transition-all ${
              currentTab === 'quiz'
                ? 'bg-amber-500 text-white shadow-xs'
                : 'text-slate-600 hover:bg-amber-50 hover:text-amber-900'
            }`}
          >
            <Brain className="w-4 h-4" />
            <span>Quiz Arena</span>
          </button>

          <button
            id="nav-tab-scramble"
            onClick={() => onSelectTab('scramble')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl whitespace-nowrap transition-all ${
              currentTab === 'scramble'
                ? 'bg-amber-500 text-white shadow-xs'
                : 'text-slate-600 hover:bg-amber-50 hover:text-amber-900'
            }`}
          >
            <Award className="w-4 h-4" />
            <span>Verse Memory Scramble</span>
          </button>

          <button
            id="nav-tab-stories"
            onClick={() => onSelectTab('stories')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl whitespace-nowrap transition-all ${
              currentTab === 'stories'
                ? 'bg-amber-500 text-white shadow-xs'
                : 'text-slate-600 hover:bg-amber-50 hover:text-amber-900'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>Story Theater</span>
          </button>

          <button
            id="nav-tab-buddy"
            onClick={() => onSelectTab('buddy')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl whitespace-nowrap transition-all ${
              currentTab === 'buddy'
                ? 'bg-amber-500 text-white shadow-xs'
                : 'text-slate-600 hover:bg-amber-50 hover:text-amber-900'
            }`}
          >
            <Bot className="w-4 h-4 text-sky-500" />
            <span>Bible Buddy AI</span>
          </button>

          <button
            id="nav-tab-rewards"
            onClick={() => onSelectTab('rewards')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl whitespace-nowrap transition-all ${
              currentTab === 'rewards'
                ? 'bg-amber-500 text-white shadow-xs'
                : 'text-slate-600 hover:bg-amber-50 hover:text-amber-900'
            }`}
          >
            <Trophy className="w-4 h-4 text-yellow-500" />
            <span>Badges & Streaks</span>
          </button>

          <button
            id="nav-tab-suggestions"
            onClick={() => onSelectTab('suggestions')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl whitespace-nowrap transition-all ml-auto ${
              currentTab === 'suggestions'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'bg-indigo-50 text-indigo-700 hover:bg-indigo-100'
            }`}
          >
            <Globe className="w-4 h-4" />
            <span>biblekidsroom.com Guide</span>
          </button>
        </nav>

      </div>
    </header>
  );
};
