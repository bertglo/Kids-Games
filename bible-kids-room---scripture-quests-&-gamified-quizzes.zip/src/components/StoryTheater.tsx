import React, { useState } from 'react';
import { BookOpen, Volume2, VolumeX, Sparkles, Star, ChevronLeft, ChevronRight, Heart, HelpCircle, Bot, Loader2, ArrowRight } from 'lucide-react';
import confetti from 'canvas-confetti';
import { BibleStory, ChildProfile } from '../types';
import { speakText, stopSpeech, playSoundEffect } from '../utils/audio';

interface StoryTheaterProps {
  stories: BibleStory[];
  profile: ChildProfile;
  onReadStory: (storyId: string, xpEarned: number) => void;
  soundEnabled: boolean;
}

export const StoryTheater: React.FC<StoryTheaterProps> = ({
  stories,
  profile,
  onReadStory,
  soundEnabled
}) => {
  const [selectedStoryIndex, setSelectedStoryIndex] = useState<number>(0);
  const [isPlayingAudio, setIsPlayingAudio] = useState<boolean>(false);
  const [activeParagraphIndex, setActiveParagraphIndex] = useState<number>(0);
  const [showAiModal, setShowAiModal] = useState<boolean>(false);
  const [isGeneratingAiStory, setIsGeneratingAiStory] = useState<boolean>(false);
  const [aiTheme, setAiTheme] = useState<string>('Courage & Bravery');
  const [aiCharacter, setAiCharacter] = useState<string>('David');
  const [customStory, setCustomStory] = useState<BibleStory | null>(null);

  const activeStory = customStory || stories[selectedStoryIndex] || stories[0];

  const handleToggleNarration = () => {
    if (isPlayingAudio) {
      stopSpeech();
      setIsPlayingAudio(false);
    } else {
      setIsPlayingAudio(true);
      if (soundEnabled) playSoundEffect('click');
      
      const fullNarration = `${activeStory.title}. ${activeStory.subtitle}. ${activeStory.paragraphs.join(' ')}. Moral Lesson: ${activeStory.moralLesson}`;
      
      speakText(fullNarration, () => {
        setIsPlayingAudio(false);
        onReadStory(activeStory.id, 40);
        if (soundEnabled) playSoundEffect('star');
      });
    }
  };

  const handleGenerateAiStory = async () => {
    setIsGeneratingAiStory(true);
    try {
      const res = await fetch('/api/gemini/story', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          storyTheme: aiTheme,
          childName: profile.name,
          character: aiCharacter
        })
      });
      const data = await res.json();
      if (data.title && data.storyParagraphs) {
        const generated: BibleStory = {
          id: `ai-story-${Date.now()}`,
          title: data.title,
          subtitle: `A special bedtime adventure created for ${profile.name}`,
          category: 'AI Adventure',
          scripture: data.verse || 'Holy Bible',
          readTime: '3 min',
          coverEmoji: '✨',
          bgGradient: 'from-purple-600 via-indigo-600 to-blue-700',
          summary: data.moralLesson || 'A heartwarming Bible adventure.',
          paragraphs: data.storyParagraphs,
          moralLesson: data.moralLesson,
          memoryVerse: data.verse,
          reflectionQuestion: data.discussionQuestions?.[0] || 'How does this story inspire you today?'
        };
        setCustomStory(generated);
        setShowAiModal(false);
        if (soundEnabled) playSoundEffect('star');
        try {
          confetti({
            particleCount: 50,
            spread: 60,
            origin: { y: 0.6 }
          });
        } catch {}
      }
    } catch (err) {
      console.error('Error generating AI story:', err);
    } finally {
      setIsGeneratingAiStory(false);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner with AI Storyteller trigger */}
      <div className="bg-gradient-to-r from-purple-600 via-indigo-600 to-blue-600 rounded-3xl p-6 sm:p-8 text-white shadow-lg flex flex-col sm:flex-row items-center justify-between gap-6">
        <div className="space-y-2 text-center sm:text-left">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 text-xs font-black backdrop-blur-md">
            <BookOpen className="w-3.5 h-3.5 text-yellow-300" />
            Illustrated Audio Story Theater
          </span>
          <h2 className="text-2xl sm:text-3xl font-black tracking-tight">
            Bedtime & Devotional Bible Adventures
          </h2>
          <p className="text-sm text-purple-100 max-w-xl font-medium">
            Listen along with joyful narration, colorful illustrations, family discussion questions, and personalized bedtime prayers!
          </p>
        </div>

        <button
          id="open-ai-story-modal"
          onClick={() => setShowAiModal(true)}
          className="px-5 py-3 rounded-2xl bg-yellow-400 hover:bg-yellow-300 text-purple-950 font-black text-xs sm:text-sm shadow-md flex items-center gap-2 whitespace-nowrap transform hover:scale-105 active:scale-95 transition-all"
        >
          <Sparkles className="w-4 h-4 text-purple-900" />
          <span>Create Story for {profile.name} 🪄</span>
        </button>
      </div>

      {/* Story Selection Thumbnails Carousel */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-extrabold text-slate-800">
            Featured Illustrated Stories
          </h3>
          {customStory && (
            <button
              onClick={() => setCustomStory(null)}
              className="text-xs font-bold text-indigo-600 hover:underline"
            >
              Back to Curated Library
            </button>
          )}
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {stories.map((st, idx) => {
            const isSelected = !customStory && selectedStoryIndex === idx;
            return (
              <button
                key={st.id}
                id={`story-card-${st.id}`}
                onClick={() => {
                  stopSpeech();
                  setIsPlayingAudio(false);
                  setCustomStory(null);
                  setSelectedStoryIndex(idx);
                }}
                className={`p-4 rounded-3xl text-left border-2 transition-all flex flex-col justify-between gap-3 ${
                  isSelected
                    ? 'bg-amber-50 border-amber-500 shadow-md ring-2 ring-amber-300/50'
                    : 'bg-white border-slate-100 hover:border-slate-300 hover:shadow-xs'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-3xl">{st.coverEmoji}</span>
                  <span className="text-[10px] font-bold text-slate-400 bg-slate-100 px-2 py-0.5 rounded-full">
                    {st.readTime}
                  </span>
                </div>
                <div>
                  <h4 className="font-extrabold text-xs sm:text-sm text-slate-800 line-clamp-1">{st.title}</h4>
                  <p className="text-[11px] font-medium text-slate-500 line-clamp-1 mt-0.5">{st.scripture}</p>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Active Story Reader */}
      <div className="bg-white rounded-3xl p-6 sm:p-10 border border-amber-100 shadow-md space-y-6">
        
        {/* Story Header Hero */}
        <div className={`p-6 sm:p-8 rounded-3xl bg-gradient-to-r ${activeStory.bgGradient} text-white space-y-4 shadow-sm relative overflow-hidden`}>
          <div className="flex items-center justify-between flex-wrap gap-2">
            <span className="px-3 py-1 rounded-full bg-white/20 text-xs font-bold backdrop-blur-md">
              {activeStory.category} • {activeStory.scripture}
            </span>

            <button
              id="story-narration-btn"
              onClick={handleToggleNarration}
              className={`px-4 py-2 rounded-2xl text-xs font-black flex items-center gap-2 transition-all shadow-sm ${
                isPlayingAudio
                  ? 'bg-rose-500 text-white animate-pulse'
                  : 'bg-white text-slate-800 hover:bg-slate-50'
              }`}
            >
              {isPlayingAudio ? (
                <>
                  <VolumeX className="w-4 h-4" />
                  <span>Pause Narration</span>
                </>
              ) : (
                <>
                  <Volume2 className="w-4 h-4 text-indigo-600" />
                  <span>Read Aloud to Me 🎧</span>
                </>
              )}
            </button>
          </div>

          <div className="space-y-1">
            <div className="text-4xl mb-2">{activeStory.coverEmoji}</div>
            <h1 className="text-2xl sm:text-3xl font-black">{activeStory.title}</h1>
            <p className="text-sm font-medium text-white/90">{activeStory.subtitle}</p>
          </div>
        </div>

        {/* Story Paragraphs */}
        <div className="space-y-5 text-slate-700 text-base sm:text-lg leading-relaxed font-medium">
          {activeStory.paragraphs.map((para, pIdx) => (
            <p key={pIdx} className="p-3 sm:p-4 rounded-2xl hover:bg-amber-50/50 transition-colors">
              {para}
            </p>
          ))}
        </div>

        {/* Story Moral & Family Reflection Box */}
        <div className="p-6 rounded-3xl bg-amber-50/80 border border-amber-200 space-y-4">
          <div className="flex items-center gap-2 text-amber-900 font-extrabold text-sm sm:text-base">
            <Heart className="w-5 h-5 text-rose-500 fill-rose-500" />
            <span>Big Moral Lesson for Little Hearts</span>
          </div>
          
          <p className="text-sm sm:text-base text-slate-800 font-bold">
            "{activeStory.moralLesson}"
          </p>

          <div className="border-t border-amber-200/60 pt-3 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs font-semibold text-amber-950">
            <div className="flex items-center gap-1.5">
              <HelpCircle className="w-4 h-4 text-amber-600" />
              <span><strong>Family Question:</strong> {activeStory.reflectionQuestion}</span>
            </div>
            
            <span className="text-[11px] font-bold text-amber-800 bg-white px-2.5 py-1 rounded-lg border border-amber-200">
              📖 {activeStory.memoryVerse}
            </span>
          </div>
        </div>

      </div>

      {/* AI Bedtime Story Generator Modal */}
      {showAiModal && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in duration-150">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border border-slate-100 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-purple-100 text-purple-600 flex items-center justify-center font-bold">
                  ✨
                </div>
                <h3 className="font-extrabold text-lg text-slate-800">Create Bedtime Bible Story</h3>
              </div>
              <button onClick={() => setShowAiModal(false)} className="text-slate-400 hover:text-slate-600">✕</button>
            </div>

            <p className="text-xs text-slate-500 font-medium">
              Gemini AI will craft an inspiring, kid-friendly biblical story personalized for <strong>{profile.name}</strong>!
            </p>

            <div className="space-y-3">
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">Bible Character / Story</label>
                <div className="flex flex-wrap gap-1.5">
                  {['David', 'Noah', 'Esther', 'Daniel', 'Moses', 'Jesus & Children'].map(char => (
                    <button
                      key={char}
                      onClick={() => setAiCharacter(char)}
                      className={`text-xs font-bold px-3 py-1.5 rounded-xl border transition-all ${
                        aiCharacter === char
                          ? 'bg-purple-600 text-white border-purple-600'
                          : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {char}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">Theme / Virtue</label>
                <div className="flex flex-wrap gap-1.5">
                  {['Courage & Bravery', 'Kindness & Sharing', 'Patience & Peace', 'Thankfulness', 'God\'s Protection'].map(thm => (
                    <button
                      key={thm}
                      onClick={() => setAiTheme(thm)}
                      className={`text-xs font-bold px-3 py-1.5 rounded-xl border transition-all ${
                        aiTheme === thm
                          ? 'bg-purple-600 text-white border-purple-600'
                          : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {thm}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                onClick={() => setShowAiModal(false)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-500 hover:bg-slate-100"
              >
                Cancel
              </button>
              <button
                id="generate-story-btn"
                onClick={handleGenerateAiStory}
                disabled={isGeneratingAiStory}
                className="px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-extrabold text-xs flex items-center gap-2 shadow-sm disabled:opacity-50"
              >
                {isGeneratingAiStory ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Writing Adventure...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>Generate Story</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
