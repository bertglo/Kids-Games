import React, { useState } from 'react';
import { Brain, Sparkles, CheckCircle2, XCircle, RotateCcw, Volume2, Star, Trophy, ArrowRight, BookOpen, Loader2, Plus, Zap, ShieldAlert } from 'lucide-react';
import confetti from 'canvas-confetti';
import { QuizQuestion, ChildProfile } from '../types';
import { speakText, playSoundEffect } from '../utils/audio';

interface QuizArenaProps {
  quizBank: QuizQuestion[];
  profile: ChildProfile;
  onQuizComplete: (score: number, total: number, xpEarned: number, starsEarned: number) => void;
  soundEnabled: boolean;
}

export const QuizArena: React.FC<QuizArenaProps> = ({
  quizBank,
  profile,
  onQuizComplete,
  soundEnabled
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [activeQuestions, setActiveQuestions] = useState<QuizQuestion[]>([]);
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswerSubmitted, setIsAnswerSubmitted] = useState<boolean>(false);
  const [score, setScore] = useState<number>(0);
  const [combo, setCombo] = useState<number>(0);
  const [quizFinished, setQuizFinished] = useState<boolean>(false);
  const [isGeneratingAi, setIsGeneratingAi] = useState<boolean>(false);
  const [customTopicInput, setCustomTopicInput] = useState<string>('');
  const [showCustomModal, setShowCustomModal] = useState<boolean>(false);

  // Filter or initialize questions
  const startQuizWithCategory = (category: string) => {
    setSelectedCategory(category);
    let filtered = category === 'all' 
      ? [...quizBank]
      : quizBank.filter(q => q.category === category);
    
    if (filtered.length === 0) {
      filtered = [...quizBank];
    }
    // Shuffle and pick 5
    const shuffled = [...filtered].sort(() => 0.5 - Math.random()).slice(0, 5);
    setActiveQuestions(shuffled);
    setCurrentIndex(0);
    setSelectedOption(null);
    setIsAnswerSubmitted(false);
    setScore(0);
    setCombo(0);
    setQuizFinished(false);
    if (soundEnabled) playSoundEffect('click');
  };

  // Generate Custom AI Quiz via Gemini
  const handleGenerateAiQuiz = async () => {
    const topic = customTopicInput.trim() || 'Miracles of Jesus';
    setIsGeneratingAi(true);
    try {
      const res = await fetch('/api/gemini/quiz', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic,
          count: 5,
          ageGroup: profile.ageGroup === 'preschool' ? '4-6' : '7-11'
        })
      });
      const data = await res.json();
      if (data.questions && data.questions.length > 0) {
        const formatted: QuizQuestion[] = data.questions.map((q: any, i: number) => ({
          id: `ai-${Date.now()}-${i}`,
          question: q.question,
          options: q.options,
          correctAnswerIndex: q.correctAnswerIndex ?? 0,
          scriptureReference: q.scriptureReference || 'Holy Bible',
          explanation: q.explanation || 'Great job exploring the scriptures!',
          funFact: q.funFact || 'God loves curious minds!',
          category: 'general',
          difficulty: 'medium'
        }));
        setActiveQuestions(formatted);
        setCurrentIndex(0);
        setSelectedOption(null);
        setIsAnswerSubmitted(false);
        setScore(0);
        setCombo(0);
        setQuizFinished(false);
        setShowCustomModal(false);
        setSelectedCategory('custom');
        if (soundEnabled) playSoundEffect('star');
      }
    } catch (err) {
      console.error('Failed to generate AI quiz:', err);
      // Fallback
      startQuizWithCategory('heroes');
      setShowCustomModal(false);
    } finally {
      setIsGeneratingAi(false);
    }
  };

  const currentQ = activeQuestions[currentIndex];

  const handleSelectOption = (idx: number) => {
    if (isAnswerSubmitted) return;
    setSelectedOption(idx);
    setIsAnswerSubmitted(true);

    const isCorrect = idx === currentQ.correctAnswerIndex;
    if (isCorrect) {
      setScore(prev => prev + 1);
      setCombo(prev => prev + 1);
      if (soundEnabled) playSoundEffect('correct');
      try {
        confetti({
          particleCount: 40,
          spread: 50,
          origin: { y: 0.7 }
        });
      } catch {}
    } else {
      setCombo(0);
      if (soundEnabled) playSoundEffect('wrong');
    }
  };

  const handleNextQuestion = () => {
    if (currentIndex < activeQuestions.length - 1) {
      setCurrentIndex(prev => prev + 1);
      setSelectedOption(null);
      setIsAnswerSubmitted(false);
      if (soundEnabled) playSoundEffect('click');
    } else {
      // Quiz finished
      setQuizFinished(true);
      const total = activeQuestions.length;
      const finalScore = score + (selectedOption === currentQ.correctAnswerIndex ? 1 : 0);
      const xpEarned = finalScore * 20 + (finalScore === total ? 50 : 0);
      const starsEarned = finalScore * 2;
      
      if (soundEnabled) {
        playSoundEffect(finalScore >= 3 ? 'levelup' : 'star');
      }
      try {
        confetti({
          particleCount: 100,
          spread: 80,
          origin: { y: 0.5 }
        });
      } catch {}

      onQuizComplete(finalScore, total, xpEarned, starsEarned);
    }
  };

  const handleReadQuestionAloud = () => {
    if (!currentQ) return;
    const text = `Question: ${currentQ.question}. Options: 1: ${currentQ.options[0]}, 2: ${currentQ.options[1]}, 3: ${currentQ.options[2]}, 4: ${currentQ.options[3]}`;
    speakText(text);
  };

  // If no quiz started yet, show categories picker
  if (activeQuestions.length === 0) {
    return (
      <div className="space-y-6">
        
        {/* Intro banner */}
        <div className="bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 rounded-3xl p-6 sm:p-8 text-white shadow-lg flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="space-y-2 text-center sm:text-left">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 text-xs font-black backdrop-blur-md">
              <Zap className="w-3.5 h-3.5 text-yellow-300" />
              Interactive Kids Bible Arena
            </span>
            <h2 className="text-2xl sm:text-3xl font-black tracking-tight">
              Test Your Scripture Knowledge!
            </h2>
            <p className="text-sm text-amber-100 max-w-xl font-medium">
              Earn Stars ⭐, unlock special badges, and level up your character while discovering amazing Bible heroes and lessons!
            </p>
          </div>

          <button
            id="open-ai-quiz-modal"
            onClick={() => setShowCustomModal(true)}
            className="px-5 py-3 rounded-2xl bg-white text-orange-600 hover:bg-amber-50 font-black text-sm shadow-md flex items-center gap-2 whitespace-nowrap transform hover:scale-105 active:scale-95 transition-all"
          >
            <Sparkles className="w-4 h-4 text-amber-500" />
            <span>AI Custom Topic Quiz 🪄</span>
          </button>
        </div>

        {/* Categories Grid */}
        <div className="space-y-4">
          <h3 className="text-base font-extrabold text-slate-800 flex items-center gap-2">
            <span>Choose a Bible Quiz Arena</span>
            <span className="text-xs font-semibold text-slate-400 bg-slate-100 px-2 py-0.5 rounded-full">5 Questions</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            
            <div 
              id="quiz-cat-all"
              onClick={() => startQuizWithCategory('all')}
              className="group bg-white p-5 rounded-3xl border-2 border-amber-200 hover:border-amber-400 hover:shadow-md cursor-pointer transition-all flex items-center gap-4"
            >
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-400 to-orange-500 text-white flex items-center justify-center text-2xl shadow-sm group-hover:scale-110 transition-transform">
                ⚡
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <h4 className="font-extrabold text-slate-800 group-hover:text-amber-600 transition-colors">Daily Sprint</h4>
                  <span className="text-xs font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded-md">Popular</span>
                </div>
                <p className="text-xs text-slate-500 font-medium mt-0.5">A fun mix of Bible stories, heroes, and memory facts.</p>
              </div>
            </div>

            <div 
              id="quiz-cat-heroes"
              onClick={() => startQuizWithCategory('heroes')}
              className="group bg-white p-5 rounded-3xl border-2 border-slate-100 hover:border-orange-300 hover:shadow-md cursor-pointer transition-all flex items-center gap-4"
            >
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-orange-400 to-rose-500 text-white flex items-center justify-center text-2xl shadow-sm group-hover:scale-110 transition-transform">
                🛡️
              </div>
              <div className="flex-1">
                <h4 className="font-extrabold text-slate-800 group-hover:text-orange-600 transition-colors">Heroes of Faith</h4>
                <p className="text-xs text-slate-500 font-medium mt-0.5">David, Daniel, Esther, Moses, and Joshua.</p>
              </div>
            </div>

            <div 
              id="quiz-cat-jesus"
              onClick={() => startQuizWithCategory('jesus')}
              className="group bg-white p-5 rounded-3xl border-2 border-slate-100 hover:border-blue-300 hover:shadow-md cursor-pointer transition-all flex items-center gap-4"
            >
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-blue-400 to-indigo-600 text-white flex items-center justify-center text-2xl shadow-sm group-hover:scale-110 transition-transform">
                ✨
              </div>
              <div className="flex-1">
                <h4 className="font-extrabold text-slate-800 group-hover:text-blue-600 transition-colors">Jesus & Miracles</h4>
                <p className="text-xs text-slate-500 font-medium mt-0.5">The life, parables, and miracles of Jesus Christ.</p>
              </div>
            </div>

            <div 
              id="quiz-cat-animals"
              onClick={() => startQuizWithCategory('animals')}
              className="group bg-white p-5 rounded-3xl border-2 border-slate-100 hover:border-emerald-300 hover:shadow-md cursor-pointer transition-all flex items-center gap-4"
            >
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-emerald-400 to-teal-600 text-white flex items-center justify-center text-2xl shadow-sm group-hover:scale-110 transition-transform">
                🦁
              </div>
              <div className="flex-1">
                <h4 className="font-extrabold text-slate-800 group-hover:text-emerald-600 transition-colors">Animals in the Bible</h4>
                <p className="text-xs text-slate-500 font-medium mt-0.5">Noah's Ark, lions, doves, whales, and donkeys.</p>
              </div>
            </div>

            <div 
              id="quiz-cat-fruit"
              onClick={() => startQuizWithCategory('fruit')}
              className="group bg-white p-5 rounded-3xl border-2 border-slate-100 hover:border-pink-300 hover:shadow-md cursor-pointer transition-all flex items-center gap-4"
            >
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-pink-400 to-purple-600 text-white flex items-center justify-center text-2xl shadow-sm group-hover:scale-110 transition-transform">
                🍇
              </div>
              <div className="flex-1">
                <h4 className="font-extrabold text-slate-800 group-hover:text-pink-600 transition-colors">Fruit of the Spirit</h4>
                <p className="text-xs text-slate-500 font-medium mt-0.5">Love, joy, peace, patience, kindness, and faith.</p>
              </div>
            </div>

            <div 
              id="quiz-cat-custom-card"
              onClick={() => setShowCustomModal(true)}
              className="group bg-gradient-to-br from-indigo-50 to-purple-50 p-5 rounded-3xl border-2 border-indigo-200 border-dashed hover:border-indigo-400 cursor-pointer transition-all flex items-center gap-4"
            >
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-indigo-500 to-purple-600 text-white flex items-center justify-center text-2xl shadow-sm group-hover:scale-110 transition-transform">
                🪄
              </div>
              <div className="flex-1">
                <h4 className="font-extrabold text-indigo-900 group-hover:text-indigo-600 transition-colors">AI Quiz Generator</h4>
                <p className="text-xs text-indigo-700 font-medium mt-0.5">Type any Bible topic or chapter to play instantly!</p>
              </div>
            </div>

          </div>
        </div>

        {/* Custom AI Quiz Modal */}
        {showCustomModal && (
          <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in duration-150">
            <div className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border border-slate-100 space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-9 h-9 rounded-xl bg-amber-100 text-amber-600 flex items-center justify-center font-bold">
                    🪄
                  </div>
                  <h3 className="font-extrabold text-lg text-slate-800">Generate Custom Bible Quiz</h3>
                </div>
                <button
                  onClick={() => setShowCustomModal(false)}
                  className="p-1 rounded-lg text-slate-400 hover:text-slate-600"
                >
                  ✕
                </button>
              </div>

              <p className="text-xs text-slate-500 font-medium">
                Choose any Bible theme, hero, or book (e.g. "Jonah & the Whale", "Creation", "Queen Esther", "The 10 Commandments", "Beatitudes"):
              </p>

              <input
                id="custom-quiz-topic-input"
                type="text"
                value={customTopicInput}
                onChange={(e) => setCustomTopicInput(e.target.value)}
                placeholder="e.g. David and Goliath, Beatitudes, Noah"
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-amber-500 text-sm font-semibold text-slate-800"
              />

              <div className="flex items-center gap-1.5 flex-wrap">
                {['David & Goliath', 'Jonah & the Whale', 'Noah’s Ark', 'Creation', 'Armor of God'].map(preset => (
                  <button
                    key={preset}
                    onClick={() => setCustomTopicInput(preset)}
                    className="text-[11px] font-bold px-2.5 py-1 rounded-lg bg-amber-50 text-amber-800 hover:bg-amber-100 transition-colors"
                  >
                    + {preset}
                  </button>
                ))}
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  onClick={() => setShowCustomModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-slate-500 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  id="submit-ai-quiz-btn"
                  onClick={handleGenerateAiQuiz}
                  disabled={isGeneratingAi}
                  className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-extrabold text-xs flex items-center gap-2 shadow-sm disabled:opacity-50"
                >
                  {isGeneratingAi ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Generating with Gemini AI...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4" />
                      <span>Create Quiz & Play</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        )}

      </div>
    );
  }

  // Quiz Finished Screen
  if (quizFinished) {
    const isPerfect = score === activeQuestions.length;
    return (
      <div className="max-w-xl mx-auto bg-white rounded-3xl p-8 border border-amber-100 shadow-xl text-center space-y-6 animate-in zoom-in-95 duration-200">
        
        <div className="w-20 h-20 mx-auto rounded-3xl bg-gradient-to-tr from-amber-400 to-orange-500 text-white flex items-center justify-center text-4xl shadow-lg">
          {isPerfect ? '👑' : score >= 3 ? '🏆' : '🌟'}
        </div>

        <div className="space-y-1">
          <span className="text-xs font-black uppercase tracking-wider text-amber-600 bg-amber-50 px-3 py-1 rounded-full">
            Quiz Complete!
          </span>
          <h2 className="text-2xl sm:text-3xl font-black text-slate-800">
            {isPerfect ? 'Magnificent! Perfect Score!' : score >= 3 ? 'Great Job, Scripture Explorer!' : 'Good Effort! Keep Growing!'}
          </h2>
          <p className="text-sm font-medium text-slate-500">
            You got <strong className="text-amber-600 font-extrabold">{score}</strong> out of <strong className="text-slate-700">{activeQuestions.length}</strong> questions correct.
          </p>
        </div>

        {/* Rewards earned card */}
        <div className="grid grid-cols-2 gap-3 bg-amber-50/70 p-4 rounded-2xl border border-amber-200">
          <div className="flex items-center justify-center gap-2">
            <Star className="w-5 h-5 text-amber-500 fill-amber-400" />
            <div className="text-left">
              <p className="text-xs text-amber-800 font-medium">Stars Earned</p>
              <p className="text-base font-black text-amber-900">+{score * 2} Stars</p>
            </div>
          </div>

          <div className="flex items-center justify-center gap-2">
            <div className="text-lg">⚡</div>
            <div className="text-left">
              <p className="text-xs text-amber-800 font-medium">XP Earned</p>
              <p className="text-base font-black text-amber-900">+{score * 20 + (isPerfect ? 50 : 0)} XP</p>
            </div>
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
          <button
            id="play-again-btn"
            onClick={() => startQuizWithCategory(selectedCategory)}
            className="w-full sm:w-auto px-6 py-3 rounded-2xl bg-amber-500 hover:bg-amber-600 text-white font-extrabold text-sm shadow-md flex items-center justify-center gap-2 transition-all"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Play Again</span>
          </button>

          <button
            id="choose-other-quiz-btn"
            onClick={() => setActiveQuestions([])}
            className="w-full sm:w-auto px-6 py-3 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-sm transition-all"
          >
            <span>Pick Another Category</span>
          </button>
        </div>

      </div>
    );
  }

  // Active Quiz Question View
  return (
    <div className="max-w-3xl mx-auto space-y-6">
      
      {/* Top Question Status bar */}
      <div className="flex items-center justify-between bg-white p-4 rounded-2xl border border-amber-100 shadow-xs">
        <div className="flex items-center gap-2">
          <span className="text-xs font-black bg-amber-100 text-amber-900 px-3 py-1 rounded-xl">
            Question {currentIndex + 1} of {activeQuestions.length}
          </span>
          {combo > 1 && (
            <span className="text-xs font-black bg-orange-500 text-white px-2.5 py-1 rounded-xl flex items-center gap-1 animate-bounce">
              🔥 {combo}x Combo!
            </span>
          )}
        </div>

        <div className="flex items-center gap-3">
          <button
            id="read-quiz-aloud-btn"
            onClick={handleReadQuestionAloud}
            className="p-2 rounded-xl text-amber-700 hover:bg-amber-50 transition-colors"
            title="Read Question Aloud"
          >
            <Volume2 className="w-4 h-4" />
          </button>

          <button
            onClick={() => setActiveQuestions([])}
            className="text-xs font-bold text-slate-400 hover:text-slate-600"
          >
            Exit Quiz
          </button>
        </div>
      </div>

      {/* Question Card */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-amber-100 shadow-md space-y-6">
        
        <div className="space-y-2">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
            {currentQ.category.toUpperCase()} • {currentQ.difficulty.toUpperCase()}
          </span>
          <h2 className="text-lg sm:text-2xl font-black text-slate-800 leading-snug">
            {currentQ.question}
          </h2>
        </div>

        {/* 4 Multiple Choice Options */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {currentQ.options.map((opt, idx) => {
            const isSelected = selectedOption === idx;
            const isCorrect = idx === currentQ.correctAnswerIndex;
            
            let btnStyle = 'border-slate-200 hover:border-amber-400 hover:bg-amber-50/50 bg-white text-slate-800';
            
            if (isAnswerSubmitted) {
              if (isCorrect) {
                btnStyle = 'border-emerald-500 bg-emerald-50 text-emerald-950 ring-2 ring-emerald-400/50';
              } else if (isSelected && !isCorrect) {
                btnStyle = 'border-rose-400 bg-rose-50 text-rose-950';
              } else {
                btnStyle = 'border-slate-100 bg-slate-50 text-slate-400 opacity-60';
              }
            }

            return (
              <button
                key={idx}
                id={`quiz-option-${idx}`}
                onClick={() => handleSelectOption(idx)}
                disabled={isAnswerSubmitted}
                className={`p-4 rounded-2xl border-2 text-left font-bold text-sm sm:text-base flex items-center justify-between gap-2 transition-all ${btnStyle}`}
              >
                <div className="flex items-center gap-3">
                  <span className="w-7 h-7 rounded-xl bg-slate-100 text-slate-600 flex items-center justify-center text-xs font-black">
                    {String.fromCharCode(65 + idx)}
                  </span>
                  <span>{opt}</span>
                </div>

                {isAnswerSubmitted && isCorrect && (
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 fill-emerald-100 shrink-0" />
                )}
                {isAnswerSubmitted && isSelected && !isCorrect && (
                  <XCircle className="w-5 h-5 text-rose-500 fill-rose-100 shrink-0" />
                )}
              </button>
            );
          })}
        </div>

        {/* Feedback / Scripture Reference card when answered */}
        {isAnswerSubmitted && (
          <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 space-y-2 animate-in fade-in duration-200">
            <div className="flex items-center justify-between">
              <span className="text-xs font-black text-amber-900 flex items-center gap-1.5">
                <BookOpen className="w-3.5 h-3.5 text-amber-600" />
                Scripture Reference: <strong className="underline">{currentQ.scriptureReference}</strong>
              </span>
              <span className="text-xs font-bold text-emerald-700">
                {selectedOption === currentQ.correctAnswerIndex ? '🎉 Correct! +20 XP' : '💡 Keep learning!'}
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-700 font-medium">
              {currentQ.explanation}
            </p>
            {currentQ.funFact && (
              <p className="text-xs text-amber-800 font-semibold bg-white/70 p-2 rounded-xl border border-amber-100">
                ✨ <strong>Fun Fact:</strong> {currentQ.funFact}
              </p>
            )}
          </div>
        )}

        {/* Next Question CTA */}
        {isAnswerSubmitted && (
          <div className="flex justify-end pt-2">
            <button
              id="next-question-btn"
              onClick={handleNextQuestion}
              className="px-6 py-3 rounded-2xl bg-amber-500 hover:bg-amber-600 text-white font-black text-sm shadow-md flex items-center gap-2 transform hover:scale-105 active:scale-95 transition-all"
            >
              <span>{currentIndex < activeQuestions.length - 1 ? 'Next Question' : 'Finish Quiz & See Score'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}

      </div>

    </div>
  );
};
