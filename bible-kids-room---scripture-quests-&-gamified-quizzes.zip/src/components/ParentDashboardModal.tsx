import React, { useState } from 'react';
import { Users, Star, Flame, Award, BookOpen, Plus, Check, Trash2, Shield, Download, FileText } from 'lucide-react';
import { ChildProfile } from '../types';

interface ParentDashboardModalProps {
  isOpen: boolean;
  onClose: () => void;
  profiles: ChildProfile[];
  activeProfileId: string;
  onSelectProfile: (id: string) => void;
  onAddProfile: (name: string, avatar: string, ageGroup: 'preschool' | 'early' | 'tween') => void;
  onUpdateStreak: (profileId: string, streak: number) => void;
}

export const ParentDashboardModal: React.FC<ParentDashboardModalProps> = ({
  isOpen,
  onClose,
  profiles,
  activeProfileId,
  onSelectProfile,
  onAddProfile,
  onUpdateStreak
}) => {
  const [newChildName, setNewChildName] = useState('');
  const [newChildAvatar, setNewChildAvatar] = useState('🦁');
  const [newChildAgeGroup, setNewChildAgeGroup] = useState<'preschool' | 'early' | 'tween'>('early');
  const [showAddForm, setShowAddForm] = useState(false);
  const [copiedReport, setCopiedReport] = useState(false);

  if (!isOpen) return null;

  const currentActive = profiles.find(p => p.id === activeProfileId) || profiles[0];

  const handleAddChild = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newChildName.trim()) return;
    onAddProfile(newChildName.trim(), newChildAvatar, newChildAgeGroup);
    setNewChildName('');
    setShowAddForm(false);
  };

  const handleExportWeeklyReport = () => {
    const report = `=== BIBLE KIDS ROOM (biblekidsroom.com) WEEKLY PROGRESS REPORT ===
Child: ${currentActive.name}
Rank Level: Level ${currentActive.level}
Daily Reading Streak: ${currentActive.streakDays} Days
Total Stars: ${currentActive.stars}
Total XP: ${currentActive.xp} XP
Quizzes Completed: ${currentActive.completedQuizCount}
Questions Answered: ${currentActive.totalQuestionsAnswered} (${currentActive.correctAnswersCount} Correct)
Verses Memorized: ${currentActive.memorizedVerseIds.length}
Badges Unlocked: ${currentActive.unlockedBadgeIds.length} / 8
Generated on: ${new Date().toLocaleDateString()}`;

    navigator.clipboard.writeText(report);
    setCopiedReport(true);
    setTimeout(() => setCopiedReport(false), 2500);
  };

  const availableAvatars = ['🦁', '🐑', '🕊️', '👑', '⭐', '🛡️', '🦊', '🦄', '🐬', '🦸‍♂️', '🦸‍♀️'];

  return (
    <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in duration-150">
      <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl border border-amber-100 space-y-6 overflow-y-auto max-h-[90vh]">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-100 text-amber-700 flex items-center justify-center font-bold">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-lg text-slate-800">Parent & Sunday School Leader Room</h3>
              <p className="text-xs text-slate-400 font-medium">Manage children profiles, monitor reading streaks, and export reports</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 font-bold"
          >
            ✕
          </button>
        </div>

        {/* Children Profile Switcher & Add Button */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-black uppercase text-slate-400">Children Profiles</h4>
            <button
              onClick={() => setShowAddForm(!showAddForm)}
              className="text-xs font-bold text-amber-700 hover:text-amber-800 flex items-center gap-1"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Another Child</span>
            </button>
          </div>

          {showAddForm && (
            <form onSubmit={handleAddChild} className="p-4 rounded-2xl bg-amber-50/70 border border-amber-200 space-y-3 animate-in fade-in duration-150">
              <h5 className="text-xs font-bold text-amber-900">Add New Child Profile</h5>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] font-bold text-slate-600 block mb-1">Child Name</label>
                  <input
                    type="text"
                    required
                    value={newChildName}
                    onChange={(e) => setNewChildName(e.target.value)}
                    placeholder="e.g. Elijah, Grace, Sarah"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-800 bg-white"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-bold text-slate-600 block mb-1">Age Group</label>
                  <select
                    value={newChildAgeGroup}
                    onChange={(e) => setNewChildAgeGroup(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-800 bg-white"
                  >
                    <option value="preschool">Preschool (Ages 3-5)</option>
                    <option value="early">Early Reader (Ages 6-8)</option>
                    <option value="tween">Junior Explorer (Ages 9-12)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-600 block mb-1">Choose Mascot / Avatar</label>
                <div className="flex flex-wrap gap-1.5">
                  {availableAvatars.map(av => (
                    <button
                      type="button"
                      key={av}
                      onClick={() => setNewChildAvatar(av)}
                      className={`text-lg p-1.5 rounded-xl border ${
                        newChildAvatar === av ? 'bg-amber-200 border-amber-500' : 'bg-white border-slate-200'
                      }`}
                    >
                      {av}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="px-3 py-1.5 rounded-xl text-xs font-bold text-slate-500"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-xl bg-amber-500 text-white text-xs font-bold shadow-xs hover:bg-amber-600"
                >
                  Save Profile
                </button>
              </div>
            </form>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {profiles.map((p) => {
              const isSelected = p.id === activeProfileId;
              return (
                <div
                  key={p.id}
                  onClick={() => onSelectProfile(p.id)}
                  className={`p-3.5 rounded-2xl border-2 cursor-pointer transition-all flex items-center justify-between gap-2 ${
                    isSelected
                      ? 'bg-amber-50/80 border-amber-500 shadow-xs'
                      : 'bg-white border-slate-100 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{p.avatar}</span>
                    <div>
                      <p className="text-xs font-extrabold text-slate-800">{p.name}</p>
                      <p className="text-[10px] text-slate-500 font-medium">
                        Level {p.level} • {p.streakDays}d Streak 🔥 • {p.stars} ⭐
                      </p>
                    </div>
                  </div>
                  {isSelected && <Check className="w-4 h-4 text-amber-600" />}
                </div>
              );
            })}
          </div>
        </div>

        {/* Selected Child Progress Overview */}
        <div className="p-4 sm:p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-black uppercase text-slate-500">
              {currentActive.name}'s Scripture Mastery
            </h4>
            <span className="text-xs font-bold text-amber-700 bg-amber-100/70 px-2 py-0.5 rounded-md">
              {currentActive.ageGroup.toUpperCase()}
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
            <div className="bg-white p-3 rounded-xl border border-slate-100">
              <span className="text-xs text-slate-400 font-medium">Daily Streak</span>
              <p className="text-lg font-black text-orange-600">{currentActive.streakDays} Days</p>
            </div>

            <div className="bg-white p-3 rounded-xl border border-slate-100">
              <span className="text-xs text-slate-400 font-medium">Total XP</span>
              <p className="text-lg font-black text-amber-600">{currentActive.xp} XP</p>
            </div>

            <div className="bg-white p-3 rounded-xl border border-slate-100">
              <span className="text-xs text-slate-400 font-medium">Quiz Accuracy</span>
              <p className="text-lg font-black text-emerald-600">
                {currentActive.totalQuestionsAnswered > 0
                  ? `${Math.round((currentActive.correctAnswersCount / currentActive.totalQuestionsAnswered) * 100)}%`
                  : '100%'}
              </p>
            </div>

            <div className="bg-white p-3 rounded-xl border border-slate-100">
              <span className="text-xs text-slate-400 font-medium">Verses Mastered</span>
              <p className="text-lg font-black text-purple-600">{currentActive.memorizedVerseIds.length}</p>
            </div>
          </div>

          {/* Adjust Streak Controls for testing / manual adjustment */}
          <div className="pt-2 flex items-center justify-between text-xs text-slate-600 border-t border-slate-200">
            <span>Manually Adjust Streak:</span>
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => onUpdateStreak(currentActive.id, Math.max(0, currentActive.streakDays - 1))}
                className="w-6 h-6 rounded-lg bg-white border border-slate-200 font-bold hover:bg-slate-100"
              >
                -
              </button>
              <span className="font-bold text-slate-800 px-1">{currentActive.streakDays}</span>
              <button
                onClick={() => onUpdateStreak(currentActive.id, currentActive.streakDays + 1)}
                className="w-6 h-6 rounded-lg bg-white border border-slate-200 font-bold hover:bg-slate-100"
              >
                +
              </button>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
          <button
            onClick={handleExportWeeklyReport}
            className="w-full sm:w-auto px-4 py-2.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-xs font-bold text-slate-700 flex items-center justify-center gap-1.5 transition-colors"
          >
            <FileText className="w-3.5 h-3.5 text-amber-600" />
            <span>{copiedReport ? 'Report Copied to Clipboard!' : 'Copy Weekly Progress Report'}</span>
          </button>

          <button
            onClick={onClose}
            className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-slate-900 text-white text-xs font-bold hover:bg-slate-800 transition-colors"
          >
            Close Dashboard
          </button>
        </div>

      </div>
    </div>
  );
};
