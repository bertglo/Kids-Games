import React, { useState } from 'react';
import { Trophy, Flame, Star, Award, Shield, Printer, CheckCircle2, Lock, Sparkles, Share2 } from 'lucide-react';
import { Badge, ChildProfile } from '../types';
import { playSoundEffect } from '../utils/audio';

interface RewardsHallProps {
  badges: Badge[];
  profile: ChildProfile;
  onUseStreakShield: () => void;
  soundEnabled: boolean;
}

export const RewardsHall: React.FC<RewardsHallProps> = ({
  badges,
  profile,
  onUseStreakShield,
  soundEnabled
}) => {
  const [showCertificateModal, setShowCertificateModal] = useState<boolean>(false);

  const getRankTitle = (lvl: number) => {
    if (lvl === 1) return 'Little Lamb 🐑';
    if (lvl === 2) return 'Brave Dove 🕊️';
    if (lvl === 3) return 'Mighty Lion 🦁';
    if (lvl === 4) return 'Armor Knight 🛡️';
    return 'Faith Champion 👑';
  };

  const handlePrintCertificate = () => {
    window.print();
  };

  // 7-day streak calendar simulation
  const daysOfWeek = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

  return (
    <div className="space-y-6">
      
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-yellow-500 via-amber-500 to-orange-500 rounded-3xl p-6 sm:p-8 text-white shadow-lg flex flex-col sm:flex-row items-center justify-between gap-6">
        <div className="space-y-2 text-center sm:text-left">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 text-xs font-black backdrop-blur-md">
            <Trophy className="w-3.5 h-3.5 text-yellow-200" />
            Scripture Hall of Champions
          </span>
          <h2 className="text-2xl sm:text-3xl font-black">
            Streaks, Badges & Rewards
          </h2>
          <p className="text-xs sm:text-sm text-amber-100 max-w-lg font-medium">
            Celebrate every scripture step! Keep your daily flame blazing, unlock hero badges, and print your official certificate!
          </p>
        </div>

        <button
          id="open-cert-btn"
          onClick={() => setShowCertificateModal(true)}
          className="px-5 py-3 rounded-2xl bg-white text-amber-900 hover:bg-amber-50 font-black text-xs sm:text-sm shadow-md flex items-center gap-2 whitespace-nowrap transform hover:scale-105 active:scale-95 transition-all"
        >
          <Award className="w-4 h-4 text-amber-600" />
          <span>Print Award Certificate 📜</span>
        </button>
      </div>

      {/* Gamified Streak & Shields Dashboard */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        
        {/* Daily Streak Flame Card */}
        <div className="bg-white rounded-3xl p-6 border border-amber-100 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-2xl bg-orange-100 text-orange-600 flex items-center justify-center font-bold text-xl">
                🔥
              </div>
              <div>
                <h3 className="font-extrabold text-slate-800 text-base">Daily Reading Streak</h3>
                <p className="text-xs text-slate-400 font-medium">Read scripture every single day</p>
              </div>
            </div>
            <span className="text-2xl font-black text-orange-600">{profile.streakDays} Days</span>
          </div>

          {/* 7-day mini tracker circles */}
          <div className="grid grid-cols-7 gap-2 pt-2">
            {daysOfWeek.map((day, idx) => {
              const isChecked = idx < Math.min(7, profile.streakDays);
              return (
                <div key={day} className="text-center space-y-1">
                  <div className={`w-9 h-9 sm:w-10 sm:h-10 mx-auto rounded-2xl flex items-center justify-center text-xs font-black transition-all ${
                    isChecked
                      ? 'bg-gradient-to-tr from-orange-500 to-amber-500 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-400'
                  }`}>
                    {isChecked ? '🔥' : day.charAt(0)}
                  </div>
                  <span className="text-[10px] font-bold text-slate-500">{day}</span>
                </div>
              );
            })}
          </div>

          <div className="p-3 bg-orange-50 rounded-2xl border border-orange-100 text-xs font-semibold text-orange-950 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-orange-600 shrink-0" />
            <span>Next Milestone: <strong>{profile.streakDays < 3 ? '3-Day Fire Spark' : profile.streakDays < 7 ? '7-Day Golden Flame' : '14-Day Torch'}</strong></span>
          </div>
        </div>

        {/* Streak Shields (Streak Freeze) */}
        <div className="bg-white rounded-3xl p-6 border border-amber-100 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-2xl bg-emerald-100 text-emerald-600 flex items-center justify-center font-bold text-xl">
                🛡️
              </div>
              <div>
                <h3 className="font-extrabold text-slate-800 text-base">Streak Shields (Freeze)</h3>
                <p className="text-xs text-slate-400 font-medium">Protects your streak if you miss a day</p>
              </div>
            </div>
            <span className="text-2xl font-black text-emerald-600">{profile.streakShields}</span>
          </div>

          <p className="text-xs text-slate-600 font-medium leading-relaxed">
            Going on vacation, camping, or had a busy day? Streak shields automatically activate so you never lose your hard-earned flame!
          </p>

          <div className="flex items-center justify-between pt-2">
            <span className="text-xs font-bold text-slate-500">Shields automatically refresh weekly.</span>
            <button
              onClick={() => {
                if (soundEnabled) playSoundEffect('star');
                onUseStreakShield();
              }}
              className="px-3.5 py-1.5 rounded-xl bg-emerald-50 text-emerald-800 hover:bg-emerald-100 text-xs font-bold transition-colors"
            >
              Test Shield Protection
            </button>
          </div>
        </div>

      </div>

      {/* Badges Collection */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-amber-100 shadow-xs space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-black text-slate-800">Earned Scripture Badges</h3>
            <p className="text-xs text-slate-400 font-medium">Complete daily quests, quizzes, and verse scrambles to collect them all!</p>
          </div>
          <span className="text-xs font-extrabold text-amber-800 bg-amber-100 px-3 py-1 rounded-full">
            {profile.unlockedBadgeIds.length} of {badges.length} Unlocked
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {badges.map((badge) => {
            const isUnlocked = profile.unlockedBadgeIds.includes(badge.id);
            return (
              <div
                key={badge.id}
                className={`p-4 rounded-3xl border-2 text-center space-y-2 transition-all ${
                  isUnlocked
                    ? 'bg-gradient-to-b from-amber-50/80 to-orange-50/50 border-amber-300 shadow-xs'
                    : 'bg-slate-50/80 border-slate-200 opacity-60'
                }`}
              >
                <div className={`w-14 h-14 mx-auto rounded-2xl flex items-center justify-center text-3xl shadow-xs ${
                  isUnlocked ? 'bg-white' : 'bg-slate-200'
                }`}>
                  {isUnlocked ? badge.icon : '🔒'}
                </div>

                <div>
                  <h4 className="text-xs sm:text-sm font-extrabold text-slate-800 line-clamp-1">{badge.title}</h4>
                  <p className="text-[10px] text-slate-500 font-medium line-clamp-2 mt-0.5">{badge.description}</p>
                </div>

                <div className="pt-1">
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                    isUnlocked ? 'bg-amber-100 text-amber-800' : 'bg-slate-200 text-slate-500'
                  }`}>
                    {isUnlocked ? '✓ Unlocked' : badge.requirement}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Printable Certificate Modal */}
      {showCertificateModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl border border-amber-200 space-y-6 overflow-y-auto max-h-[90vh]">
            
            {/* Header controls */}
            <div className="flex items-center justify-between">
              <span className="text-xs font-black uppercase text-amber-600">Official Award Certificate</span>
              <button
                onClick={() => setShowCertificateModal(false)}
                className="text-slate-400 hover:text-slate-700 font-bold"
              >
                ✕ Close
              </button>
            </div>

            {/* Printable Certificate Preview Box */}
            <div 
              id="printable-certificate"
              className="p-8 sm:p-12 rounded-3xl bg-amber-50/30 border-8 border-amber-400 text-center space-y-5 relative shadow-inner"
            >
              <div className="flex items-center justify-center gap-2">
                <span className="text-3xl">⭐</span>
                <span className="text-3xl">👑</span>
                <span className="text-3xl">⭐</span>
              </div>

              <div className="space-y-1">
                <h2 className="text-xs font-black tracking-widest uppercase text-amber-800">
                  BibleKidsRoom.com • Scripture Champions
                </h2>
                <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
                  Certificate of Scripture Achievement
                </h1>
                <p className="text-xs text-slate-500 italic">This award is proudly presented to:</p>
              </div>

              <div className="py-2 border-b-2 border-amber-300 max-w-xs mx-auto">
                <p className="text-2xl sm:text-3xl font-black text-amber-700">
                  {profile.name}
                </p>
              </div>

              <p className="text-xs sm:text-sm text-slate-700 max-w-md mx-auto leading-relaxed font-medium">
                For outstanding dedication to reading God's Word, mastering scripture memory verses, maintaining a <strong>{profile.streakDays}-Day Reading Streak</strong>, and earning <strong>{profile.stars} Stars</strong>!
              </p>

              <div className="grid grid-cols-2 gap-4 pt-4 text-xs font-bold text-slate-600 border-t border-amber-200/60 max-w-sm mx-auto">
                <div>
                  <p className="text-amber-800">Date</p>
                  <p className="text-slate-700">{new Date().toLocaleDateString()}</p>
                </div>
                <div>
                  <p className="text-amber-800">Rank Title</p>
                  <p className="text-slate-700">{getRankTitle(profile.level)}</p>
                </div>
              </div>

              <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-amber-200/60 rounded-full text-[10px] font-black text-amber-900">
                <span>🛡️ Verified at BibleKidsRoom.com</span>
              </div>
            </div>

            {/* Print & Action buttons */}
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setShowCertificateModal(false)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-500 hover:bg-slate-100"
              >
                Done
              </button>
              <button
                id="do-print-btn"
                onClick={handlePrintCertificate}
                className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-extrabold text-xs flex items-center gap-2 shadow-sm"
              >
                <Printer className="w-4 h-4" />
                <span>Print / Save as PDF 🖨️</span>
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
