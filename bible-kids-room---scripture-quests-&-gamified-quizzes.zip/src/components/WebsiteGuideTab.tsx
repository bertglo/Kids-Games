import React, { useState } from 'react';
import { Globe, Code2, Sparkles, CheckCircle2, Copy, Flame, Brain, Award, BookOpen, Smartphone, ShieldCheck, Zap, ArrowUpRight } from 'lucide-react';
import { BIBLE_KIDS_ROOM_APP_SUGGESTIONS } from '../data/initialData';

export const WebsiteGuideTab: React.FC = () => {
  const [copiedCodeId, setCopiedCodeId] = useState<string | null>(null);

  const handleCopyCode = (id: string, code?: string) => {
    if (!code) return;
    navigator.clipboard.writeText(code);
    setCopiedCodeId(id);
    setTimeout(() => setCopiedCodeId(null), 2500);
  };

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      
      {/* Hero Recommendation Header */}
      <div className="bg-gradient-to-r from-indigo-900 via-indigo-800 to-purple-900 rounded-3xl p-6 sm:p-10 text-white shadow-xl space-y-4">
        <div className="flex items-center gap-2 text-indigo-300 text-xs font-black uppercase tracking-wider">
          <Globe className="w-4 h-4 text-amber-400" />
          <span>Strategic App Suite for biblekidsroom.com</span>
        </div>

        <h1 className="text-2xl sm:text-4xl font-black tracking-tight">
          Recommended Apps & Gamified Modules for <span className="text-amber-400">BibleKidsRoom.com</span>
        </h1>

        <p className="text-sm sm:text-base text-indigo-100 max-w-3xl leading-relaxed font-medium">
          Here is a purpose-built roadmap of interactive applications designed to transform your website into an irresistible daily destination for kids, parents, and Sunday schools to learn scripture, build reading streaks, and master Bible knowledge!
        </p>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
          <div className="bg-white/10 backdrop-blur-md p-3.5 rounded-2xl border border-white/10 text-center">
            <span className="text-2xl">🔥</span>
            <p className="text-xs font-bold text-white mt-1">Daily Streak Engine</p>
            <p className="text-[10px] text-indigo-200">Boosts daily return visits</p>
          </div>

          <div className="bg-white/10 backdrop-blur-md p-3.5 rounded-2xl border border-white/10 text-center">
            <span className="text-2xl">🧠</span>
            <p className="text-xs font-bold text-white mt-1">Quiz Arena</p>
            <p className="text-[10px] text-indigo-200">Interactive sound & scores</p>
          </div>

          <div className="bg-white/10 backdrop-blur-md p-3.5 rounded-2xl border border-white/10 text-center">
            <span className="text-2xl">🧩</span>
            <p className="text-xs font-bold text-white mt-1">Memory Scrambles</p>
            <p className="text-[10px] text-indigo-200">Kinetic verse memorization</p>
          </div>

          <div className="bg-white/10 backdrop-blur-md p-3.5 rounded-2xl border border-white/10 text-center">
            <span className="text-2xl">📜</span>
            <p className="text-xs font-bold text-white mt-1">Printable Awards</p>
            <p className="text-[10px] text-indigo-200">Viral parent sharing</p>
          </div>
        </div>
      </div>

      {/* Suggested Apps Breakdown */}
      <div className="space-y-6">
        <h2 className="text-xl font-black text-slate-800 flex items-center gap-2">
          <span>5 High-Impact Web Apps to Deploy on Your Site</span>
        </h2>

        <div className="grid grid-cols-1 gap-6">
          {BIBLE_KIDS_ROOM_APP_SUGGESTIONS.map((app, idx) => (
            <div
              key={app.id}
              className="bg-white rounded-3xl p-6 sm:p-8 border border-amber-100 shadow-xs space-y-4 hover:shadow-md transition-shadow"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-amber-100 text-amber-800 flex items-center justify-center font-black text-sm">
                    0{idx + 1}
                  </div>
                  <div>
                    <span className="text-[10px] font-black uppercase tracking-wider text-amber-700 bg-amber-50 px-2 py-0.5 rounded-md">
                      {app.category}
                    </span>
                    <h3 className="text-lg sm:text-xl font-extrabold text-slate-900 mt-0.5">
                      {app.title}
                    </h3>
                  </div>
                </div>
              </div>

              <p className="text-sm text-slate-700 font-medium leading-relaxed">
                {app.summary}
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
                <div className="p-4 rounded-2xl bg-amber-50/60 border border-amber-100 text-xs text-amber-950 space-y-1">
                  <strong className="text-amber-900 block flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                    Why Kids Love It:
                  </strong>
                  <p className="text-slate-700 font-medium">{app.howItEngagesKids}</p>
                </div>

                <div className="p-4 rounded-2xl bg-indigo-50/60 border border-indigo-100 text-xs text-indigo-950 space-y-1">
                  <strong className="text-indigo-900 block flex items-center gap-1.5">
                    <Globe className="w-3.5 h-3.5 text-indigo-600" />
                    How to Position on BibleKidsRoom.com:
                  </strong>
                  <p className="text-slate-700 font-medium">{app.bibleKidsRoomFit}</p>
                </div>
              </div>

              {/* Sample Embed Snippet */}
              {app.sampleEmbedCode && (
                <div className="p-3 rounded-2xl bg-slate-900 text-slate-200 font-mono text-xs flex items-center justify-between gap-3 overflow-x-auto">
                  <div className="flex items-center gap-2 shrink-0">
                    <Code2 className="w-4 h-4 text-amber-400" />
                    <span className="text-[11px] text-slate-400 font-sans font-bold">Embed Code Snippet:</span>
                  </div>
                  <code className="text-amber-300 truncate">{app.sampleEmbedCode}</code>
                  <button
                    onClick={() => handleCopyCode(app.id, app.sampleEmbedCode)}
                    className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-[11px] font-sans font-bold flex items-center gap-1 shrink-0 transition-colors"
                  >
                    {copiedCodeId === app.id ? (
                      <>
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy Code</span>
                      </>
                    )}
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Gamification Best Practices for Kids */}
      <div className="bg-amber-500 rounded-3xl p-6 sm:p-8 text-white space-y-4 shadow-md">
        <h3 className="text-xl font-black">
          3 Golden Rules of Gamified Bible Learning for Kids:
        </h3>
        
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="bg-white/15 p-4 rounded-2xl backdrop-blur-xs space-y-1">
            <h4 className="font-extrabold text-sm text-yellow-200">1. Instant Joyful Feedback</h4>
            <p className="text-xs text-amber-100 font-medium">Use pleasant sound chimes, confetti bursts, and celebratory avatar reactions when children answer questions or complete verses.</p>
          </div>

          <div className="bg-white/15 p-4 rounded-2xl backdrop-blur-xs space-y-1">
            <h4 className="font-extrabold text-sm text-yellow-200">2. Forgiving Streaks (Shields)</h4>
            <p className="text-xs text-amber-100 font-medium">Never discourage a child by wiping out a 20-day streak on one missed busy day. Provide "Streak Freeze Shields" like this app implements.</p>
          </div>

          <div className="bg-white/15 p-4 rounded-2xl backdrop-blur-xs space-y-1">
            <h4 className="font-extrabold text-sm text-yellow-200">3. Physical & Digital Rewards</h4>
            <p className="text-xs text-amber-100 font-medium">Bridge the digital app with the physical home using printable milestone certificates they can hang on their bedroom wall!</p>
          </div>
        </div>
      </div>

    </div>
  );
};
