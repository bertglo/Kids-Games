import React, { useState } from 'react';
import { Volume2, VolumeX, Sparkles, Flame, CheckCircle2, Star, ArrowRight, Share2, HelpCircle, Lightbulb, ChevronLeft, ChevronRight, Check } from 'lucide-react';
import confetti from 'canvas-confetti';
import { ScriptureQuest, ChildProfile } from '../types';
import { speakText, stopSpeech, playSoundEffect } from '../utils/audio';

interface DailyQuestHeroProps {
  quests: ScriptureQuest[];
  currentQuestIndex: number;
  onSelectQuestIndex: (index: number) => void;
  profile: ChildProfile;
  onCompleteQuest: (quest: ScriptureQuest) => void;
  onJumpToScramble: (verseText: string, reference: string) => void;
  soundEnabled: boolean;
}

export const DailyQuestHero: React.FC<DailyQuestHeroProps> = ({
  quests,
  currentQuestIndex,
  onSelectQuestIndex,
  profile,
  onCompleteQuest,
  onJumpToScramble,
  soundEnabled
}) => {
  const quest = quests[currentQuestIndex] || quests[0];
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [activeTab, setActiveTab] = useState<'meaning' | 'challenge' | 'funfact'>('meaning');

  // Check if today's quest has been completed today
  const isCompletedToday = profile.lastReadDate === new Date().toISOString().split('T')[0];

  const handleToggleAudio = () => {
    if (isPlayingAudio) {
      stopSpeech();
      setIsPlayingAudio(false);
    } else {
      setIsPlayingAudio(true);
      if (soundEnabled) playSoundEffect('click');
      const textToRead = `${quest.reference}. ${quest.simplifiedForKids}. What this means: ${quest.kidTakeaway}. Today's challenge: ${quest.actionChallenge}`;
      speakText(textToRead, () => {
        setIsPlayingAudio(false);
      });
    }
  };

  const handleComplete = () => {
    if (soundEnabled) {
      playSoundEffect('streak');
    }
    // Fire confetti celebration
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 }
      });
    } catch {}

    onCompleteQuest(quest);
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: `Bible Kids Room Daily Quest - ${quest.reference}`,
        text: `Check out today's verse on BibleKidsRoom.com: "${quest.verseText}" (${quest.reference})`,
        url: window.location.href,
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(`"${quest.verseText}" - ${quest.reference} (BibleKidsRoom.com)`);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Top Header Banner & Day Navigation */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 sm:p-5 rounded-3xl border border-amber-100 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-amber-500 text-white flex items-center justify-center font-black text-xl shadow-xs">
            #{quest.dayNumber}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-black uppercase tracking-wider text-amber-600 bg-amber-50 px-2 py-0.5 rounded-md">
                Daily Scripture Quest
              </span>
              <span className="text-xs font-semibold text-slate-400">
                Theme: <strong className="text-slate-700">{quest.theme}</strong>
              </span>
            </div>
            <h1 className="text-lg sm:text-xl font-black text-slate-800">
              {quest.reference}
            </h1>
          </div>
        </div>

        {/* Day Selector controls */}
        <div className="flex items-center gap-2 self-end sm:self-center">
          <button
            id="prev-quest-btn"
            onClick={() => {
              if (currentQuestIndex > 0) {
                stopSpeech();
                setIsPlayingAudio(false);
                onSelectQuestIndex(currentQuestIndex - 1);
              }
            }}
            disabled={currentQuestIndex === 0}
            className="p-2 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
            title="Previous Day's Quest"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          
          <span className="text-xs font-bold text-slate-500 px-1">
            Day {quest.dayNumber} of {quests.length}
          </span>

          <button
            id="next-quest-btn"
            onClick={() => {
              if (currentQuestIndex < quests.length - 1) {
                stopSpeech();
                setIsPlayingAudio(false);
                onSelectQuestIndex(currentQuestIndex + 1);
              }
            }}
            disabled={currentQuestIndex === quests.length - 1}
            className="p-2 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
            title="Next Day's Quest"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Scripture Card */}
      <div className="relative overflow-hidden bg-gradient-to-br from-amber-500 via-orange-500 to-amber-600 rounded-3xl p-6 sm:p-10 text-white shadow-xl">
        
        {/* Floating Decorative Elements */}
        <div className="absolute -top-12 -right-12 w-48 h-48 rounded-full bg-white/10 blur-2xl pointer-events-none" />
        <div className="absolute -bottom-10 -left-10 w-40 h-40 rounded-full bg-yellow-300/20 blur-xl pointer-events-none" />

        <div className="relative z-10 space-y-6">
          
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-white text-xs font-bold border border-white/20">
              <Sparkles className="w-3.5 h-3.5 text-yellow-200" />
              <span>Kids Easy-to-Read Edition</span>
            </div>

            <div className="flex items-center gap-2">
              <button
                id="share-verse-btn"
                onClick={handleShare}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs font-bold transition-all"
              >
                {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-300" /> : <Share2 className="w-3.5 h-3.5" />}
                <span>{copiedLink ? 'Copied!' : 'Share'}</span>
              </button>

              <button
                id="listen-verse-btn"
                onClick={handleToggleAudio}
                className={`inline-flex items-center gap-1.5 px-4 py-1.5 rounded-xl text-xs font-extrabold transition-all shadow-sm ${
                  isPlayingAudio
                    ? 'bg-rose-500 text-white animate-pulse'
                    : 'bg-white text-orange-600 hover:bg-amber-50'
                }`}
              >
                {isPlayingAudio ? (
                  <>
                    <VolumeX className="w-4 h-4" />
                    <span>Stop Audio</span>
                  </>
                ) : (
                  <>
                    <Volume2 className="w-4 h-4" />
                    <span>Read to Me 🎧</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Big Child-Friendly Verse Text */}
          <div className="space-y-3">
            <blockquote className="text-xl sm:text-2xl md:text-3xl font-extrabold leading-snug tracking-tight text-white drop-shadow-xs">
              "{quest.simplifiedForKids}"
            </blockquote>
            
            <p className="text-sm sm:text-base font-medium text-amber-100 italic border-l-2 border-white/30 pl-3">
              Standard text: "{quest.verseText}" — <span className="font-bold text-white not-italic">{quest.reference}</span>
            </p>
          </div>

          {/* Action Footer on Banner */}
          <div className="pt-4 border-t border-white/20 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
            
            <div className="flex items-center gap-2 text-xs font-bold text-amber-100">
              <span className="flex items-center gap-1 bg-white/20 px-2.5 py-1 rounded-lg">
                <Star className="w-3.5 h-3.5 text-yellow-300 fill-yellow-300" />
                +{quest.starsReward} Stars
              </span>
              <span className="flex items-center gap-1 bg-white/20 px-2.5 py-1 rounded-lg">
                ⚡ +{quest.xpReward} XP
              </span>
              <span className="flex items-center gap-1 bg-white/20 px-2.5 py-1 rounded-lg">
                <Flame className="w-3.5 h-3.5 text-yellow-300 fill-yellow-300" />
                +1 Day Streak
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                id="scramble-jump-btn"
                onClick={() => onJumpToScramble(quest.verseText, quest.reference)}
                className="px-4 py-2 rounded-2xl bg-white/15 hover:bg-white/25 text-white font-bold text-xs sm:text-sm transition-all flex items-center justify-center gap-1.5"
              >
                <span>Practice Scramble</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>

              <button
                id="complete-quest-btn"
                onClick={handleComplete}
                className={`px-5 py-2.5 rounded-2xl font-black text-xs sm:text-sm shadow-lg transition-all flex items-center justify-center gap-2 ${
                  isCompletedToday
                    ? 'bg-emerald-400 text-emerald-950 cursor-default'
                    : 'bg-yellow-300 hover:bg-yellow-200 text-amber-950 transform hover:scale-105 active:scale-95'
                }`}
              >
                {isCompletedToday ? (
                  <>
                    <CheckCircle2 className="w-4 h-4 text-emerald-900 fill-emerald-200" />
                    <span>Streak Active Today! 🔥</span>
                  </>
                ) : (
                  <>
                    <Flame className="w-4 h-4 text-orange-600 fill-orange-500" />
                    <span>Mark Read & Keep Streak!</span>
                  </>
                )}
              </button>
            </div>

          </div>

        </div>
      </div>

      {/* Interactive Tabs: Meaning for Kids | Today's Action Challenge | Fun Fact */}
      <div className="bg-white rounded-3xl p-6 border border-amber-100 shadow-xs space-y-5">
        <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
          <button
            onClick={() => setActiveTab('meaning')}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-1.5 transition-all ${
              activeTab === 'meaning'
                ? 'bg-amber-100 text-amber-900 shadow-xs'
                : 'text-slate-500 hover:bg-slate-50'
            }`}
          >
            <Lightbulb className="w-4 h-4 text-amber-500" />
            <span>What This Means For Me</span>
          </button>

          <button
            onClick={() => setActiveTab('challenge')}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-1.5 transition-all ${
              activeTab === 'challenge'
                ? 'bg-orange-100 text-orange-900 shadow-xs'
                : 'text-slate-500 hover:bg-slate-50'
            }`}
          >
            <Sparkles className="w-4 h-4 text-orange-500" />
            <span>Today's Action Challenge</span>
          </button>

          <button
            onClick={() => setActiveTab('funfact')}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-1.5 transition-all ${
              activeTab === 'funfact'
                ? 'bg-sky-100 text-sky-900 shadow-xs'
                : 'text-slate-500 hover:bg-slate-50'
            }`}
          >
            <HelpCircle className="w-4 h-4 text-sky-500" />
            <span>Bible Fun Fact</span>
          </button>
        </div>

        {/* Tab content bodies */}
        {activeTab === 'meaning' && (
          <div className="space-y-3 animate-in fade-in duration-200">
            <div className="flex items-start gap-3 p-4 rounded-2xl bg-amber-50/60 border border-amber-100">
              <span className="text-2xl">💡</span>
              <div>
                <h3 className="font-extrabold text-sm text-amber-900 mb-1">Kid Life Takeaway</h3>
                <p className="text-sm text-slate-700 leading-relaxed font-medium">
                  {quest.kidTakeaway}
                </p>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'challenge' && (
          <div className="space-y-3 animate-in fade-in duration-200">
            <div className="flex items-start gap-3 p-4 rounded-2xl bg-orange-50/60 border border-orange-100">
              <span className="text-2xl">🎯</span>
              <div>
                <h3 className="font-extrabold text-sm text-orange-900 mb-1">Put Faith Into Action</h3>
                <p className="text-sm text-slate-700 leading-relaxed font-medium">
                  {quest.actionChallenge}
                </p>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'funfact' && (
          <div className="space-y-3 animate-in fade-in duration-200">
            <div className="flex items-start gap-3 p-4 rounded-2xl bg-sky-50/60 border border-sky-100">
              <span className="text-2xl">🔍</span>
              <div>
                <h3 className="font-extrabold text-sm text-sky-900 mb-1">Did You Know?</h3>
                <p className="text-sm text-slate-700 leading-relaxed font-medium">
                  {quest.funFact}
                </p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Week Scripture Streak Milestones preview */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-orange-100 text-orange-600 flex items-center justify-center text-xl font-bold">
            🔥
          </div>
          <div>
            <p className="text-xs text-slate-500 font-medium">Current Streak</p>
            <p className="text-sm font-black text-slate-800">{profile.streakDays} Days Strong</p>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-600 flex items-center justify-center text-xl font-bold">
            ⭐
          </div>
          <div>
            <p className="text-xs text-slate-500 font-medium">Total Stars</p>
            <p className="text-sm font-black text-slate-800">{profile.stars} Stars</p>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center text-xl font-bold">
            🛡️
          </div>
          <div>
            <p className="text-xs text-slate-500 font-medium">Streak Shields</p>
            <p className="text-sm font-black text-slate-800">{profile.streakShields} Available</p>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-100 text-purple-600 flex items-center justify-center text-xl font-bold">
            🏆
          </div>
          <div>
            <p className="text-xs text-slate-500 font-medium">Badges Earned</p>
            <p className="text-sm font-black text-slate-800">{profile.unlockedBadgeIds.length} / 8</p>
          </div>
        </div>
      </div>

    </div>
  );
};
