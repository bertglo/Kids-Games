import React, { useState } from 'react';
import { Bot, Send, Sparkles, Volume2, HelpCircle, Loader2, BookOpen, Heart, RefreshCw } from 'lucide-react';
import { ChildProfile } from '../types';
import { speakText, playSoundEffect } from '../utils/audio';

interface BibleBuddyChatProps {
  profile: ChildProfile;
  soundEnabled: boolean;
}

interface ChatMessage {
  id: string;
  sender: 'user' | 'buddy';
  text: string;
  scripture?: string;
  reflection?: string;
  funAnalogy?: string;
}

export const BibleBuddyChat: React.FC<BibleBuddyChatProps> = ({ profile, soundEnabled }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      sender: 'buddy',
      text: `Hi ${profile.name}! 👋 I'm your Bible Buddy! You can ask me anything you're curious about in the Bible—like why Noah built an ark, what miracles Jesus did, or how you can be brave and kind today!`,
      scripture: 'Psalm 119:105',
      reflection: 'God loves your curious questions and wants to teach your heart every day!'
    }
  ]);
  const [inputQuery, setInputQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const sampleQuestions = [
    'Why did Noah need two of every animal?',
    'What was Jesus\'s favorite story to tell?',
    'How tall was the giant Goliath?',
    'Why did the walls of Jericho fall down?',
    'How can I pray when I feel scared?'
  ];

  const handleSendMessage = async (queryText?: string) => {
    const textToSend = (queryText || inputQuery).trim();
    if (!textToSend || isLoading) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: textToSend
    };

    setMessages(prev => [...prev, userMsg]);
    setInputQuery('');
    setIsLoading(true);
    if (soundEnabled) playSoundEffect('click');

    try {
      const res = await fetch('/api/gemini/ask-bible-buddy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question: textToSend,
          childAge: profile.ageGroup === 'preschool' ? 5 : profile.ageGroup === 'early' ? 8 : 11
        })
      });

      const data = await res.json();

      const buddyMsg: ChatMessage = {
        id: `buddy-${Date.now()}`,
        sender: 'buddy',
        text: data.answer || 'God loves you and has an amazing plan for your life!',
        scripture: data.scripture,
        reflection: data.reflection,
        funAnalogy: data.funAnalogy
      };

      setMessages(prev => [...prev, buddyMsg]);
      if (soundEnabled) playSoundEffect('star');
    } catch (err) {
      console.error('Bible Buddy error:', err);
      const fallbackMsg: ChatMessage = {
        id: `buddy-fallback-${Date.now()}`,
        sender: 'buddy',
        text: `That is a wonderful question! The Bible tells us that God is full of love, wisdom, and kindness. Whenever you read scripture, remember God is right beside you!`,
        scripture: 'Jeremiah 29:11',
        reflection: 'Take a quiet moment today to say "Thank You God for loving me!"'
      };
      setMessages(prev => [...prev, fallbackMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleRecite = (text: string) => {
    speakText(text);
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      
      {/* Header card */}
      <div className="bg-gradient-to-r from-sky-500 via-blue-600 to-indigo-600 rounded-3xl p-6 sm:p-8 text-white shadow-lg flex items-center justify-between gap-4">
        <div className="space-y-1">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 text-xs font-black backdrop-blur-md">
            <Bot className="w-3.5 h-3.5 text-yellow-300" />
            AI Junior Scripture Explorer
          </span>
          <h2 className="text-2xl sm:text-3xl font-black">
            Ask Bible Buddy Anything!
          </h2>
          <p className="text-xs sm:text-sm text-sky-100 font-medium max-w-lg">
            Safe, cheerful, scripture-backed answers to your biggest questions with fun analogies and memory verses.
          </p>
        </div>

        <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-3xl bg-white/20 backdrop-blur-md flex items-center justify-center text-4xl shadow-inner border border-white/20">
          🤖
        </div>
      </div>

      {/* Suggested Quick Questions */}
      <div className="space-y-2">
        <span className="text-xs font-bold text-slate-400 flex items-center gap-1">
          <Sparkles className="w-3.5 h-3.5 text-amber-500" />
          Popular Curious Questions for Kids:
        </span>
        <div className="flex flex-wrap gap-2">
          {sampleQuestions.map((q, idx) => (
            <button
              key={idx}
              onClick={() => handleSendMessage(q)}
              className="text-xs font-bold px-3 py-1.5 rounded-xl bg-white hover:bg-sky-50 border border-slate-200 hover:border-sky-300 text-slate-700 hover:text-sky-800 shadow-2xs transition-all active:scale-95 text-left"
            >
              💬 {q}
            </button>
          ))}
        </div>
      </div>

      {/* Chat Messages Box */}
      <div className="bg-white rounded-3xl p-4 sm:p-6 border border-amber-100 shadow-md min-h-96 flex flex-col justify-between space-y-4">
        
        <div className="space-y-4 overflow-y-auto max-h-96 pr-2">
          {messages.map((msg) => {
            const isBuddy = msg.sender === 'buddy';
            return (
              <div
                key={msg.id}
                className={`flex items-start gap-3 ${isBuddy ? '' : 'flex-row-reverse'}`}
              >
                <div className={`w-9 h-9 rounded-2xl flex items-center justify-center text-lg shrink-0 ${
                  isBuddy ? 'bg-sky-100 text-sky-700' : 'bg-amber-100 text-amber-800'
                }`}>
                  {isBuddy ? '🤖' : profile.avatar}
                </div>

                <div className={`p-4 rounded-3xl max-w-lg space-y-2 ${
                  isBuddy 
                    ? 'bg-slate-50 border border-slate-100 text-slate-800' 
                    : 'bg-amber-500 text-white font-semibold'
                }`}>
                  <p className="text-xs sm:text-sm leading-relaxed">
                    {msg.text}
                  </p>

                  {isBuddy && msg.funAnalogy && (
                    <div className="p-2.5 rounded-2xl bg-sky-50/80 border border-sky-100 text-xs font-medium text-sky-950">
                      💡 <strong>Kid Analogy:</strong> {msg.funAnalogy}
                    </div>
                  )}

                  {isBuddy && msg.scripture && (
                    <div className="flex items-center justify-between pt-1 border-t border-slate-200/60 text-[11px] text-slate-600 font-bold">
                      <span className="flex items-center gap-1">
                        <BookOpen className="w-3 h-3 text-amber-600" />
                        {msg.scripture}
                      </span>
                      <button
                        onClick={() => handleRecite(msg.text)}
                        className="p-1 text-slate-400 hover:text-sky-600"
                        title="Read aloud"
                      >
                        <Volume2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}

          {isLoading && (
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-2xl bg-sky-100 text-sky-700 flex items-center justify-center text-lg">
                🤖
              </div>
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 flex items-center gap-2 text-xs font-bold text-slate-500">
                <Loader2 className="w-4 h-4 animate-spin text-sky-500" />
                <span>Bible Buddy is thinking with Gemini AI...</span>
              </div>
            </div>
          )}
        </div>

        {/* Input Bar */}
        <div className="pt-2 border-t border-slate-100 flex items-center gap-2">
          <input
            id="buddy-input-field"
            type="text"
            value={inputQuery}
            onChange={(e) => setInputQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
            placeholder={`Ask Bible Buddy anything about scripture, ${profile.name}...`}
            className="flex-1 px-4 py-3 rounded-2xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-sky-400 text-xs sm:text-sm font-semibold text-slate-800"
          />

          <button
            id="buddy-send-btn"
            onClick={() => handleSendMessage()}
            disabled={!inputQuery.trim() || isLoading}
            className="p-3 sm:px-5 sm:py-3 rounded-2xl bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs sm:text-sm shadow-sm disabled:opacity-40 transition-all flex items-center gap-1.5"
          >
            <Send className="w-4 h-4" />
            <span className="hidden sm:inline">Ask</span>
          </button>
        </div>

      </div>

    </div>
  );
};
