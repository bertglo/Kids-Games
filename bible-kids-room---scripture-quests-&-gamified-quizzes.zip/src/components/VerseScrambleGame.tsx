import React, { useState, useEffect } from 'react';
import { Award, Volume2, RotateCcw, CheckCircle2, Sparkles, Star, ChevronLeft, ChevronRight, HelpCircle, Eye, EyeOff } from 'lucide-react';
import confetti from 'canvas-confetti';
import { MemoryVersePuzzle, ChildProfile } from '../types';
import { speakText, playSoundEffect } from '../utils/audio';

interface VerseScrambleGameProps {
  verses: MemoryVersePuzzle[];
  profile: ChildProfile;
  onMasterVerse: (verseId: string, xpEarned: number, starsEarned: number) => void;
  soundEnabled: boolean;
  initialVerseReference?: string;
}

export const VerseScrambleGame: React.FC<VerseScrambleGameProps> = ({
  verses,
  profile,
  onMasterVerse,
  soundEnabled,
  initialVerseReference
}) => {
  // Find initial verse index if provided
  const findInitialIndex = () => {
    if (!initialVerseReference) return 0;
    const found = verses.findIndex(v => v.reference.toLowerCase().includes(initialVerseReference.toLowerCase()));
    return found !== -1 ? found : 0;
  };

  const [currentVerseIndex, setCurrentVerseIndex] = useState<number>(findInitialIndex());
  const activeVerse = verses[currentVerseIndex] || verses[0];

  // Scramble game state
  const [scrambledPool, setScrambledPool] = useState<{ id: string; text: string }[]>([]);
  const [constructedWords, setConstructedWords] = useState<{ id: string; text: string }[]>([]);
  const [isSolved, setIsSolved] = useState<boolean>(false);
  const [peekHint, setPeekHint] = useState<boolean>(false);
  const [mistakeNotice, setMistakeNotice] = useState<string | null>(null);

  // Initialize and shuffle words whenever active verse changes
  useEffect(() => {
    const tokens = activeVerse.words.map((w, i) => ({ id: `${w}-${i}-${Math.random()}`, text: w }));
    // Shuffle
    const shuffled = [...tokens].sort(() => 0.5 - Math.random());
    setScrambledPool(shuffled);
    setConstructedWords([]);
    setIsSolved(false);
    setPeekHint(false);
    setMistakeNotice(null);
  }, [activeVerse]);

  const handlePickWord = (token: { id: string; text: string }) => {
    if (isSolved) return;
    
    // Check if adding this word matches the next expected word
    const nextExpectedIndex = constructedWords.length;
    const expectedWord = activeVerse.words[nextExpectedIndex];
    
    // Clean punctuation for gentle comparison if needed, or exact match
    if (token.text.toLowerCase() === expectedWord.toLowerCase()) {
      // Correct word picked!
      const newConstructed = [...constructedWords, token];
      setConstructedWords(newConstructed);
      setScrambledPool(prev => prev.filter(t => t.id !== token.id));
      setMistakeNotice(null);
      
      if (soundEnabled) playSoundEffect('click');

      // Check if full verse is solved!
      if (newConstructed.length === activeVerse.words.length) {
        setIsSolved(true);
        if (soundEnabled) playSoundEffect('levelup');
        try {
          confetti({
            particleCount: 70,
            spread: 60,
            origin: { y: 0.6 }
          });
        } catch {}

        onMasterVerse(activeVerse.id, 60, 5);
      }
    } else {
      // Wrong word for next spot
      if (soundEnabled) playSoundEffect('wrong');
      setMistakeNotice(`Hint: Next word starts with "${expectedWord.charAt(0)}..."`);
      setTimeout(() => setMistakeNotice(null), 2500);
    }
  };

  const handleRemoveWord = (index: number) => {
    if (isSolved) return;
    // Remove from constructed and put back to pool
    const token = constructedWords[index];
    const newConstructed = constructedWords.filter((_, i) => i !== index);
    setConstructedWords(newConstructed);
    setScrambledPool(prev => [...prev, token]);
    if (soundEnabled) playSoundEffect('click');
  };

  const handleReset = () => {
    const tokens = activeVerse.words.map((w, i) => ({ id: `${w}-${i}-${Math.random()}`, text: w }));
    setScrambledPool([...tokens].sort(() => 0.5 - Math.random()));
    setConstructedWords([]);
    setIsSolved(false);
    setMistakeNotice(null);
    if (soundEnabled) playSoundEffect('click');
  };

  const handleReciteAloud = () => {
    speakText(`${activeVerse.reference}. ${activeVerse.fullVerse}`);
  };

  const isMastered = profile.memorizedVerseIds.includes(activeVerse.id);

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      
      {/* Top Selector & Verse Meta */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-white p-4 sm:p-5 rounded-3xl border border-amber-100 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-amber-500 text-white flex items-center justify-center text-2xl shadow-xs">
            🧩
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-black uppercase text-amber-600 bg-amber-50 px-2 py-0.5 rounded-md">
                Verse Memory Scramble
              </span>
              {isMastered && (
                <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" /> Mastered
                </span>
              )}
            </div>
            <h2 className="text-lg sm:text-xl font-black text-slate-800">
              {activeVerse.reference}
            </h2>
          </div>
        </div>

        {/* Verse Carousel Navigator */}
        <div className="flex items-center gap-2">
          <button
            id="prev-verse-scramble"
            onClick={() => {
              if (currentVerseIndex > 0) setCurrentVerseIndex(currentVerseIndex - 1);
            }}
            disabled={currentVerseIndex === 0}
            className="p-2 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          
          <span className="text-xs font-bold text-slate-500 px-2">
            {currentVerseIndex + 1} of {verses.length}
          </span>

          <button
            id="next-verse-scramble"
            onClick={() => {
              if (currentVerseIndex < verses.length - 1) setCurrentVerseIndex(currentVerseIndex + 1);
            }}
            disabled={currentVerseIndex === verses.length - 1}
            className="p-2 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Scramble Workspace */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-amber-100 shadow-md space-y-6">
        
        {/* Helper instructions & Hint / Recite buttons */}
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-4">
          <p className="text-xs sm:text-sm font-semibold text-slate-500">
            Tap the words in the right order to construct the memory verse!
          </p>

          <div className="flex items-center gap-2">
            <button
              id="peek-verse-btn"
              onClick={() => setPeekHint(!peekHint)}
              className="px-3 py-1.5 rounded-xl border border-slate-200 text-xs font-bold text-slate-600 hover:bg-slate-50 flex items-center gap-1.5 transition-all"
            >
              {peekHint ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              <span>{peekHint ? 'Hide Peek' : 'Peek Verse'}</span>
            </button>

            <button
              id="recite-verse-btn"
              onClick={handleReciteAloud}
              className="px-3 py-1.5 rounded-xl bg-amber-50 text-amber-800 hover:bg-amber-100 text-xs font-bold flex items-center gap-1.5 transition-all"
            >
              <Volume2 className="w-3.5 h-3.5 text-amber-600" />
              <span>Listen 🎧</span>
            </button>

            <button
              id="reset-scramble-btn"
              onClick={handleReset}
              className="p-1.5 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
              title="Reset Words"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Peek Hint Banner if toggled */}
        {peekHint && (
          <div className="p-3 bg-amber-50/80 rounded-2xl border border-amber-200 text-xs sm:text-sm text-amber-900 font-semibold italic animate-in fade-in duration-150">
            "{activeVerse.fullVerse}" — {activeVerse.reference}
          </div>
        )}

        {/* Target Assembly Box */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs font-bold text-slate-400">
            <span>Your Verse Construction:</span>
            <span>{constructedWords.length} / {activeVerse.words.length} words</span>
          </div>

          <div className="min-h-28 p-4 sm:p-5 rounded-2xl bg-slate-50 border-2 border-dashed border-amber-200 flex flex-wrap items-center gap-2">
            {constructedWords.length === 0 ? (
              <span className="text-xs sm:text-sm text-slate-400 italic">
                Tap words below to place them here in correct order...
              </span>
            ) : (
              constructedWords.map((word, idx) => (
                <button
                  key={word.id}
                  onClick={() => handleRemoveWord(idx)}
                  disabled={isSolved}
                  className="px-3.5 py-2 rounded-xl bg-gradient-to-tr from-amber-500 to-orange-500 text-white font-extrabold text-sm sm:text-base shadow-xs hover:bg-orange-600 hover:scale-105 active:scale-95 transition-all animate-in zoom-in-90 duration-100"
                  title="Tap to remove"
                >
                  {word.text}
                </button>
              ))
            )}
          </div>
        </div>

        {/* Mistake feedback toast */}
        {mistakeNotice && (
          <div className="p-2.5 rounded-xl bg-rose-50 border border-rose-200 text-xs font-bold text-rose-700 flex items-center gap-2 animate-in shake duration-200">
            <span>⚠️</span>
            <span>{mistakeNotice}</span>
          </div>
        )}

        {/* Word Bank (Scrambled pool) */}
        {!isSolved && (
          <div className="space-y-2">
            <span className="text-xs font-bold text-slate-400">Available Word Chips:</span>
            <div className="flex flex-wrap gap-2 p-3 bg-amber-50/40 rounded-2xl border border-amber-100">
              {scrambledPool.map((token) => (
                <button
                  key={token.id}
                  id={`word-chip-${token.text}`}
                  onClick={() => handlePickWord(token)}
                  className="px-4 py-2.5 rounded-xl bg-white hover:bg-amber-100 border-2 border-slate-200 hover:border-amber-400 text-slate-800 font-extrabold text-sm sm:text-base shadow-xs active:scale-95 transition-all"
                >
                  {token.text}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Victory Card when solved */}
        {isSolved && (
          <div className="p-6 rounded-3xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white text-center space-y-4 shadow-lg animate-in zoom-in-95 duration-200">
            <div className="w-14 h-14 mx-auto rounded-2xl bg-white/20 text-white flex items-center justify-center text-3xl">
              🎉
            </div>
            
            <div>
              <h3 className="text-xl sm:text-2xl font-black">Verse Mastered!</h3>
              <p className="text-sm font-medium text-emerald-100 mt-1">
                You memorized and assembled <strong>{activeVerse.reference}</strong>!
              </p>
            </div>

            <div className="flex items-center justify-center gap-3">
              <span className="bg-white/20 px-3 py-1.5 rounded-xl text-xs font-black flex items-center gap-1.5">
                <Star className="w-4 h-4 text-yellow-300 fill-yellow-300" />
                +5 Stars
              </span>
              <span className="bg-white/20 px-3 py-1.5 rounded-xl text-xs font-black">
                ⚡ +60 XP
              </span>
            </div>

            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                id="recite-solved-btn"
                onClick={handleReciteAloud}
                className="px-4 py-2 rounded-xl bg-white text-emerald-800 font-extrabold text-xs flex items-center gap-1.5 shadow-sm hover:bg-emerald-50"
              >
                <Volume2 className="w-4 h-4" />
                <span>Listen Again</span>
              </button>

              {currentVerseIndex < verses.length - 1 && (
                <button
                  id="next-verse-btn"
                  onClick={() => setCurrentVerseIndex(currentVerseIndex + 1)}
                  className="px-5 py-2 rounded-xl bg-yellow-400 hover:bg-yellow-300 text-emerald-950 font-black text-xs shadow-sm"
                >
                  <span>Next Verse Puzzle ➡️</span>
                </button>
              )}
            </div>
          </div>
        )}

      </div>

    </div>
  );
};
