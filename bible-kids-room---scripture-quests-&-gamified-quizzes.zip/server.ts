import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";
import { GoogleGenAI, Type } from "@google/genai";

dotenv.config();

const app = express();
const PORT = 3000;

// Allow iframe embedding on external sites (Clicksites, custom domains, etc.)
app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.removeHeader("X-Frame-Options");
  res.setHeader("Content-Security-Policy", "frame-ancestors *;");
  next();
});

app.use(express.json());

// Server-side Gemini AI client initialization
function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// 1. Dynamic Kids Quiz Generation Endpoint
app.post("/api/gemini/quiz", async (req, res) => {
  try {
    const { topic = "General Bible Heroes", count = 5, ageGroup = "7-11" } = req.body;
    const ai = getGeminiClient();

    if (!ai) {
      return res.json({
        fallback: true,
        questions: [
          {
            id: "fb-1",
            question: "Who built a giant ark to save his family and animals from the great flood?",
            options: ["Moses", "Noah", "David", "Abraham"],
            correctAnswerIndex: 1,
            scriptureReference: "Genesis 6:14",
            explanation: "God told Noah to build an ark of gopher wood because Noah walked faithfully with God!",
            funFact: "Noah's ark was longer than a football field!"
          },
          {
            id: "fb-2",
            question: "What small weapon did David use to defeat the giant Goliath?",
            options: ["A golden sword", "A sling and 5 smooth stones", "A flaming arrow", "A shield"],
            correctAnswerIndex: 1,
            scriptureReference: "1 Samuel 17:40",
            explanation: "David trusted God completely and defeated the giant with just a sling and a stone.",
            funFact: "David picked up 5 smooth stones from the stream before facing Goliath!"
          },
          {
            id: "fb-3",
            question: "How many days and nights did it rain during the Great Flood?",
            options: ["7 days", "12 days", "40 days and 40 nights", "100 days"],
            correctAnswerIndex: 2,
            scriptureReference: "Genesis 7:12",
            explanation: "Rain fell upon the earth for forty days and forty nights.",
            funFact: "After the rain, God put a rainbow in the sky as a promise!"
          }
        ]
      });
    }

    const prompt = `Generate ${count} engaging, fun, and child-friendly Bible quiz questions suitable for kids aged ${ageGroup} on the topic: "${topic}".
Include 4 multiple choice options per question, the 0-indexed correct answer, a scripture reference, an encouraging kid explanation, and a surprising Bible fun fact.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.7-flash",
      contents: prompt,
      config: {
        systemInstruction: "You are Bible Kids Room's cheerful AI Quiz Master. Make questions positive, inspiring, educational, historically accurate according to scripture, and easy to understand for children.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            questions: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.STRING },
                  question: { type: Type.STRING },
                  options: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                  },
                  correctAnswerIndex: { type: Type.INTEGER },
                  scriptureReference: { type: Type.STRING },
                  explanation: { type: Type.STRING },
                  funFact: { type: Type.STRING }
                },
                required: ["id", "question", "options", "correctAnswerIndex", "scriptureReference", "explanation", "funFact"]
              }
            }
          },
          required: ["questions"]
        }
      }
    });

    const parsed = JSON.parse(response.text || "{}");
    return res.json(parsed);
  } catch (error: any) {
    console.error("Quiz generation error:", error);
    return res.status(500).json({ error: error.message || "Failed to generate quiz" });
  }
});

// 2. Ask Bible Buddy (Junior Explorer AI)
app.post("/api/gemini/ask-bible-buddy", async (req, res) => {
  try {
    const { question, childAge = 8 } = req.body;
    if (!question) {
      return res.status(400).json({ error: "Question is required" });
    }

    const ai = getGeminiClient();
    if (!ai) {
      return res.json({
        answer: `Great question! The Bible teaches us that God loves everyone and made each of us special. When you read stories like David, Noah, or Jesus helping others, remember that God wants to be your best friend too!`,
        scripture: "Jeremiah 29:11",
        reflection: "Take a quiet moment today to say 'Thank you, God, for making me unique!'",
        funAnalogy: "Think of God's love like the brightest sunshine—it shines warmly on everyone everywhere!"
      });
    }

    const prompt = `A child aged approximately ${childAge} asks: "${question}".
Answer them warmly as 'Bible Buddy' (the mascot of Bible Kids Room).
- Keep it encouraging, simple, comforting, and faithful to scripture.
- Use fun, relatable real-world analogies suitable for kids.
- Include a key Bible verse citation, a fun thought or analogy, and a quick practical faith takeaway.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.7-flash",
      contents: prompt,
      config: {
        systemInstruction: "You are 'Bible Buddy', a loving, joyful, wise, and enthusiastic cartoon companion for children learning scripture at BibleKidsRoom.com. Speak with kindness, cheerful energy, and age-appropriate warmth.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            answer: { type: Type.STRING, description: "Child-friendly 2-3 paragraph answer." },
            scripture: { type: Type.STRING, description: "Relevant Bible verse reference and quote." },
            reflection: { type: Type.STRING, description: "A simple micro-action or thought for the child." },
            funAnalogy: { type: Type.STRING, description: "A creative kid-friendly analogy." }
          },
          required: ["answer", "scripture", "reflection", "funAnalogy"]
        }
      }
    });

    const parsed = JSON.parse(response.text || "{}");
    return res.json(parsed);
  } catch (error: any) {
    console.error("Bible Buddy error:", error);
    return res.status(500).json({ error: error.message || "Failed to get Bible Buddy response" });
  }
});

// 3. Custom Story & Bedtime Devotional Generator
app.post("/api/gemini/story", async (req, res) => {
  try {
    const { storyTheme = "Courage", childName = "Explorer", character = "David" } = req.body;
    const ai = getGeminiClient();

    if (!ai) {
      return res.json({
        title: "The Boy with the Brave Heart",
        verse: "The Lord is my strength and my shield; in him my heart trusts. — Psalm 28:7",
        storyParagraphs: [
          "Once in the sunny hills of Bethlehem, a young boy named David was looking after his father's sheep under big fluffy clouds.",
          "Whenever danger came, like a roaring lion or a hungry bear, David didn't run away in fear. He knew God was right there by his side protecting him.",
          `Just like David, ${childName} can remember that whenever you feel small or nervous, God's mighty love gives you super courage inside!`
        ],
        moralLesson: "You don't have to be big and strong to do great things with God; you just need a trusting heart.",
        discussionQuestions: [
          "What is something that made you feel nervous recently?",
          "How can remembering God help you feel brave like David?"
        ],
        prayer: `Dear God, thank You for being my protector every day. Give me a brave heart like David to do what is right and kind. Amen!`
      });
    }

    const prompt = `Write an exciting, heartwarming, beautifully descriptive 3-paragraph Bible story adventure for a child named ${childName} on the theme "${storyTheme}" focusing on ${character}. Include a key memory verse, a moral lesson, 2 discussion questions for family reflection, and a sweet bedtime prayer.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.7-flash",
      contents: prompt,
      config: {
        systemInstruction: "You are the master storyteller at Bible Kids Room. Create vivid, safe, inspiring biblical stories that spark imagination and deepen love for God's word.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            verse: { type: Type.STRING },
            storyParagraphs: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            moralLesson: { type: Type.STRING },
            discussionQuestions: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            prayer: { type: Type.STRING }
          },
          required: ["title", "verse", "storyParagraphs", "moralLesson", "discussionQuestions", "prayer"]
        }
      }
    });

    const parsed = JSON.parse(response.text || "{}");
    return res.json(parsed);
  } catch (error: any) {
    console.error("Story generation error:", error);
    return res.status(500).json({ error: error.message || "Failed to generate story" });
  }
});

// Vite middleware setup for SPA
async function start() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running at http://localhost:${PORT}`);
  });
}

start();
